import 'react-native-gesture-handler';
import React from 'react';
import LandingScreen from "./src/views/LandingScreen.js";
import { Provider as PaperProvider } from 'react-native-paper';
import HomeScreen from "./src/views/HomeScreen.js";
import LoginScreen from "./src/views/LoginScreen.js";
import ProfileScreen from "./src/views/ProfileScreen.js";
import AboutScreen from "./src/views/AboutScreen.js";
import AddServiceScreen from './src/views/AddServiceScreen.js';
import SST from './src/views/SST.js';
import ACScreen1 from './src/views/ACScreen.js';
import ChangesScreen from './src/views/ChangesScreen.js';
import CatalogScreen from './src/views/CatalogScreen.js';
import SearchScreen from './src/views/SearchScreen.js';
import MorePayments from './src/views/MorePayments.js';
import TestScreen from './src/views/TestScreen.js';
import NotificationsScreen from './src/views/NotificationsScreen.js';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { getDatabase, child, get } from "firebase/database";
import { getAuth } from "firebase/auth";
import { Text, IconButton } from 'react-native-paper';
import { createDrawerNavigator} from '@react-navigation/drawer';
import {ref} from 'firebase/database';
import { useFonts } from 'expo-font';
import {
  en,
  registerTranslation,
} from 'react-native-paper-dates'
registerTranslation('en', en)

const Stack = createNativeStackNavigator();

const Drawer = createDrawerNavigator();


// Navigation for our whole app
export default function App(navigation, route) {
  useFonts({
    'Material Design Icons': require('@expo/vector-icons/build/vendor/react-native-vector-icons/Fonts/MaterialCommunityIcons.ttf'),
  });

  return (
    <NavigationContainer>
      <PaperProvider>
        <Stack.Navigator>

          <Stack.Screen name="Landing Screen" component={LandingScreen} options={{
            headerShown: false
            }} />

          <Stack.Screen name="Login Screen" component={LoginScreen} options={{
            headerShown: false
            }}/>

          <Stack.Screen name="Create Account Screen 1" component={ACScreen1} options={{
            headerShown: false
          }}/>
          
          <Stack.Screen name="SST" component={SST}/>

          <Stack.Screen name="Profile Screen" component={ProfileScreen} options={{
              headerTitle: () => <Text style={{color: "#black", fontWeight: "bold", fontSize: 25}}><Text style={{fontWeight: "normal", color: "white", fontSize: 25}}>my</Text>Account</Text>,
              headerBackTitle: "",
              headerStyle: {backgroundColor: "#55b0ca"},
              headerTitleStyle: { fontSize: 24, color: "black" },
          }}/>

          <Stack.Screen name="Payment Screen" component={MorePayments}/>

          <Stack.Screen name="Changes Screen" component={ChangesScreen} options={{
              headerTitle: () => <Text style={{color: "#black", fontWeight: "bold", fontSize: 25}}>What's changing?</Text>,
              headerBackTitle: "",
              headerStyle: {backgroundColor: "#55b0ca"},
              headerTitleStyle: { fontSize: 24, color: "black" },
          }}/>

          <Stack.Screen name="Add Service Screen" component={AddServiceScreen} options={{
              headerTitle: () => <Text style={{color: "#black", fontWeight: "bold", fontSize: 25}}><Text style={{fontWeight: "normal", color: "white", fontSize: 25}}>my</Text>TV</Text>,
              headerBackTitle: "",
              headerStyle: {backgroundColor: "#55b0ca"},
              headerTitleStyle: { fontSize: 24, color: "black" },
          }}/>

          <Stack.Screen name="Catalog Screen" component={CatalogScreen} options={{
              headerTitle: () => <Text style={{color: "#black", fontWeight: "bold", fontSize: 25}}><Text style={{fontWeight: "normal", color: "white", fontSize: 25}}>my</Text>Catalog</Text>,
              headerBackTitle: "",
              headerStyle: {backgroundColor: "#55b0ca"},
              headerTitleStyle: { fontSize: 24, color: "black" },
          }}/>

          <Stack.Screen name="mySubscriptions" component={HomeScreen} 
              options={({ navigation }) => ({
          })}/>

          <Stack.Screen name="Search Screen" component={SearchScreen} options={{
              headerTitle: () => <Text style={{color: "#black", fontWeight: "bold", fontSize: 25}}><Text style={{fontWeight: "normal", color: "white", fontSize: 25}}>my</Text>Search</Text>,
              headerBackTitle: "",
              headerStyle: {backgroundColor: "#55b0ca"},
              headerTitleStyle: { fontSize: 24, color: "black" },
          }}/>

          <Stack.Screen name="Notifications Screen" component={NotificationsScreen} options={{
              headerTitle: () => <Text style={{color: "#black", fontWeight: "bold", fontSize: 25}}><Text style={{fontWeight: "normal", color: "white", fontSize: 25}}>my</Text>Notifications</Text>,
              headerBackTitle: "",
              headerStyle: {backgroundColor: "#55b0ca"},
              headerTitleStyle: { fontSize: 24, color: "black" },
          }}/>

          <Stack.Screen name="Test Screen" component={TestScreen} options={{
              headerTitle: () => <Text style={{color: "#black", fontWeight: "bold", fontSize: 25}}><Text style={{fontWeight: "normal", color: "white", fontSize: 25}}>my</Text>Test</Text>,
              headerBackTitle: "",
              headerStyle: {backgroundColor: "#55b0ca"},
              headerTitleStyle: { fontSize: 24, color: "black" },
          }}/>

        </Stack.Navigator>
      </PaperProvider>
    </NavigationContainer>
  );
}
