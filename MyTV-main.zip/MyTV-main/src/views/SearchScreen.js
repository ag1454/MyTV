import React, { useState } from 'react';
import { Text, View, ScrollView } from 'react-native';
import { Searchbar, Button, Portal, Modal } from 'react-native-paper';
import { getDatabase, ref, set } from "firebase/database";
import { getAuth } from "firebase/auth";
import { Entypo } from '@expo/vector-icons';
import { Display } from '../components/Display.js';
import { Dropdown } from 'react-native-element-dropdown';
import styles from '../styling/SearchScreen.style.js';

// Page object to be modified based on search results
const page = {
    current: 1,
    total: 0
};

function SearchScreen({route}) {

    // Hooks
    const [searchQuery, setSearchQuery] = useState('');
    const[searchResults, setSearchResults] = useState();
    const [visibility, setVisibility] = useState(false);
    const [dialogObject, setDialogObject] = useState();  
    const [value, setValue] = useState('movie');
    const [isFocus, setIsFocus] = useState(false);

    const media = [
        { label: 'Movie', value: 'movie' },
        { label: 'Series', value: 'series' },
    ]

    var data = [];

    var service
    if(route.params.service == "Netflix"){
        service = "netflix"
    } else if(route.params.service == "HBO") {
        service = "hbo"
    } else if(route.params.service == "Hulu") {
        service = "hulu"
    } else if(route.params.service == "Disney+") {
        service = "disney"
    }

    //
    // Function to follow a title; saves imdbID under the user's service and the movie details in the titleLibrary
    //
    function follow(title) {
        const auth = getAuth();
        let uid = auth.currentUser.uid;
        const db = getDatabase();

        set(ref(db, `users/${uid}/services/${route.params.service}/following/${title.title}`), {
            "imdbID": title.imdbID
        }).then(() => {
            set((ref(db, `titleLibrary/${title.imdbID}`)), {
                "title": title.title,
                "genres": title.genres,
                "cast": title.cast,
                "significants": title.significants,
                "year": title.year,
                "countries": title.countries,
                "poster": title.posterURLs.original
            }).then(() => {
                changeVisibility();
            })   
        })    
    }

    //
    // Function to search API based on keyword
    //
    function search() {    

        const fetch = require('node-fetch');

        // URL to get Data from API based on what is entered
        const url = 'https://streaming-availability.p.rapidapi.com/search/basic?country=us' +
                    '&service=' + service +
                    '&keyword=' + searchQuery + 
                    '&type=' + value + 
                    '&page=' + page.current +
                    '&output_language=en&language=en';
    
        // Getting API key
        const options = {
        method: 'GET',
        headers: {
            'X-RapidAPI-Key': '1b11125fe6msh8a001dd71a23db7p15705cjsn96bb6fc93404',
            'X-RapidAPI-Host': 'streaming-availability.p.rapidapi.com'
        }
        };
    
        fetch(url, options)
            .then(res => res.json())
            
            .then(json => { 
                page.total = json.total_pages;
                data = json.results;
                setSearchResults(data);
            })    
            .catch(err => console.error('error:' + err));
    }

    // 
    // function to change visibility of the dialog box
    //
    function changeVisibility() {
        if(visibility == false) {
            setVisibility(true);
        } else {
            setVisibility(false);
        }
    }

    //
    // Function to render the dialog box when the user clicks a title
    //
    function DialogBox() {
        if(dialogObject) {
            return(
                <Portal>
                <Modal
                    visible={visibility}
                    onDismiss={() => changeVisibility()}
                    contentContainerStyle={{
                        backgroundColor:'white',
                        padding:20,
                        width: 250,
                        alignSelf: "center"
                    }}>
                    <ScrollView>
                        <Text style={{alignSelf: "center", fontSize: 16, fontWeight: "bold"}}>Title:</Text>
                        <Text style={{alignSelf: "center", fontSize: 16}}>{dialogObject.title}</Text>
                        <Text style={{alignSelf: "center", fontSize: 16, fontWeight: "bold", paddingTop: 10}}>Release year:</Text>
                        <Text style={{alignSelf: "center", fontSize: 16}}>{dialogObject.year}</Text>
                        <Text style={{alignSelf: "center", fontSize: 16, fontWeight: "bold", paddingTop: 10}}>Cast:</Text>
                        <Text style={{alignSelf: "center", fontSize: 16}}>{dialogObject.cast[0] + ", " + dialogObject.cast[1] + ", " + dialogObject.cast[2]}</Text>
                        <Text style={{alignSelf: "center", fontSize: 16, fontWeight: "bold", paddingTop: 10}}>Director:</Text>
                        <Text style={{alignSelf: "center", fontSize: 16}}>{dialogObject.significants[0]}</Text>
                        <View style={{paddingTop: 20, flexDirection: "row"}}>
                            <View style={{paddingRight: 5}}>
                            <Button style={{width: 100, backgroundColor: "#99cfdf"}} onPress={() => follow(dialogObject)} mode="contained">
                                Follow
                            </Button>
                            </View>
                            <View style={{paddingRight: 10}}>
                            <Button style={{width: 100, backgroundColor: "#99cfdf"}} onPress={() => changeVisibility()} mode="contained">
                                Close
                            </Button>
                            </View>
                        </View>
                    </ScrollView>
                </Modal>
                </Portal>
            )
        }
    }

    //
    // Function to bring up next page of search results
    //
    function nextPage() {
        // Increment Page
        page.current = page.current + 1;
        search();
    }

    //
    // Function to bring up previous page of search results
    //
    function previousPage() {
        // Decrement Page
        page.current = page.current - 1;
        search();
    }

    //
    // Component to render next button
    //
    function NextButton() {
        if((page.current < page.total) && searchResults) {
            return(
                <Button mode="contained" style={{backgroundColor: "#99cfdf", width: 110, marginLeft: 15}} onPress={() => nextPage()}>Next</Button>
            );
        } else { 
            return null
        }
    }

    //
    // Component to render previous button
    //
    function PreviousButton() {
        if(page.current > 1) {
            return(
                <Button mode="contained" style={{ backgroundColor: "#99cfdf", width: 110, marginRight: 15}} onPress={() => previousPage()}>Previous</Button>
            );
        }
    }

    //
    // Screen render
    //
    return (
        <View>
            <View style={{flexDirection: "row"}}>
                <View style={{width: "25%"}}>
                    <Dropdown
                        style={[styles.dropdownGenre, isFocus && { borderColor: 'blue' }]}
                        placeholderStyle={{ fontSize: 16 }}
                        selectedTextStyle={{ fontSize: 16 }}
                        inputSearchStyle={{ height: 40, fontSize: 16 }}
                        iconStyle={styles.iconStyle}
                        data={media}
                        maxHeight={300}
                        labelField="label"
                        valueField="value"
                        placeholder={!isFocus ? 'Movie' : '...'}
                        value={value}
                        onFocus={() => setIsFocus(true)}
                        onBlur={() => setIsFocus(false)}
                        onChange={item => {
                            setValue(item.value);
                            setIsFocus(false);
                            setSearchResults();
                        }}
                    />
                </View>
                <View style={{width: "75%"}}>
                    <Searchbar
                        placeholder="Search"
                        onChangeText={query =>{
                            setSearchQuery(query);
                            setSearchResults();
                            page.current= 1;
                        }}
                        value={searchQuery}
                        icon={() => (
                            <Entypo name="magnifying-glass" size={24} color="black" />
                        )}
                        clearIcon={() => (
                            <Entypo name="squared-cross" size={24} color="black" />
                        )}
                        onSubmitEditing={() => [page.current = 1, search()]}/>
                </View>
            </View>

            <ScrollView style={{height: "80%"}}>
                <Display data={searchResults} changeVisibility={changeVisibility} setDialogObject={setDialogObject} dialogObject={dialogObject}/>
                <DialogBox/>
            </ScrollView>

            <View style={{flexDirection: "row", justifyContent: "center", paddingTop: 10}}>
                <PreviousButton/>
                <NextButton/>
            </View>
        </View>
    );
}

export default SearchScreen;