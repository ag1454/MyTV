import React, {useState, useCallback } from 'react';
import { Text, ScrollView, View, Alert } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import CustomButton from '../components/button.js';
import { useRoute } from '@react-navigation/native';
import styles from '../styling/ProfileScreen.style.js';
import { getAuth } from "firebase/auth";
import { getDatabase, ref, child, get, remove, update } from "firebase/database";
import { payment } from '../functions/payment.js';

function ProfileScreen({ navigation }, userInfo) {
  const route = useRoute();

  
  // Hooks
  const [data, setData] = useState();
  const [services, setServices] = useState();

  // Firebase config
  const auth = getAuth();
  let uid = auth.currentUser.uid;
  const dbRef = ref(getDatabase());
  
  //
  // Get the data required for the screen to render
  //
  useFocusEffect(
    useCallback(() => {

        get(child(dbRef, `users/${uid}`)).then((snapshot) => {
            if (snapshot.exists()) {
                let data = snapshot.val();
                setData(data);
                if(data.services) {
                  setServices(Object.keys(data.services))
                }
            } else {
                console.log("No data available");
            }
            }).catch((error) => {
              console.error(error);
        });

    }, [])
  );

  const userLogout = () => {
        const auth = getAuth();
        // console.log(auth.currentUser.uid);
        auth.signOut().then(() => {
            navigation.navigate('Login Screen');
        })
        .catch((error) => {
            const errorMessage = error.message;
            Alert.alert("Could not log out");
            console.log(errorMessage);
        })
    };

  function ServiceDisplay() {


    if(services) {
      return(
        <View>
        <View style={{alignItems: "center"}}>
        <Text style={{ fontSize: 22, paddingTop: 25, paddingBottom: 5, fontWeight: "bold"}}>Service History</Text>
        </View>
        {services.map(element => {
          let paymentsLength = data.services[element].subscription.payments.length;

          return(
            <View key={element}>
              <View>
                <Text style={{ fontSize: 22, paddingTop: 20, fontWeight: "bold"}}>{element}</Text>
              </View>

              <View style={{ flexDirection: "row", borderBottomWidth: 1, borderColor: "#afaeae" }}>

                <Text style={{ paddingTop: 20, paddingBottom: 10, fontSize: 17, color: "#afaeae"}}>Purchase Date</Text>

                <Text style={{ paddingTop: 20, textAlign: "right" , fontSize: 17, width: 212}}>{data.services[element].subscription.purchaseDate}</Text>

              </View>

              <View style={{ flexDirection: "row", borderBottomWidth: 1, borderColor: "#afaeae" }}>

              <Text style={{ paddingTop: 20, paddingBottom: 10, fontSize: 17, color: "#afaeae"}}>Latest Purchase</Text>

              <Text style={{ paddingTop: 20, textAlign: "right" , fontSize: 17, width: 200}}>{data.services[element].subscription.payments[paymentsLength - 1].date}</Text>

              </View>

              <View style={{ flexDirection: "row", borderBottomWidth: 1, borderColor: "#afaeae" }}>

                <Text style={{ paddingTop: 20, paddingBottom: 10, fontSize: 17, color: "#afaeae"}}>Price</Text>

                <Text style={{ paddingTop: 20, textAlign: "right" , fontSize: 17, width: 280}}>{data.services[element].subscription.price}</Text>

              </View>
              
              <View style={{ flexDirection: "row", borderBottomWidth: 1, borderColor: "#afaeae" }}>

                <Text style={{ paddingTop: 20, paddingBottom: 10, fontSize: 17, color: "#afaeae"}}>Status</Text>

                <Text style={{ paddingTop: 20, textAlign: "right" , fontSize: 17, width: 275}}>{data.services[element].subscription.status}</Text>

              </View>

            </View>
          );
        })}

        </View>
      );
    }
    else {
      return null
    }
  }

  if(data) {
    return (
      <ScrollView style={styles.container}>
        
        <View style={{ paddingTop: 30, width: 330, alignSelf: "center"}}>

          {/* Profile Account Details */}
          <View>
            <Text style={{ fontSize: 22, paddingBottom: 5, fontWeight: "bold"}}>Profile</Text>
          </View>

          <View style={{flexDirection: "row", borderBottomWidth: 1, borderColor: "#afaeae" }}>

            <Text style={{ paddingTop: 20, paddingBottom: 10, fontSize: 17, color: "#afaeae"}}>Name</Text>

            <Text style={{ paddingTop: 20, textAlign: "right" , fontSize: 17, width: 280}}>{data.profile.firstName + " " + data.profile.lastName}</Text>

          </View>

          <View style={{flexDirection: "row", borderBottomWidth: 1, borderColor: "#afaeae"}}>

            <Text style={{ paddingTop: 30, paddingBottom: 10, fontSize: 17, color: "#afaeae" }}>Email</Text>

            <Text style={{ paddingTop: 30, textAlign: "right" , fontSize: 17, width: 280}}>{data.profile.email}</Text>

          </View>

          <View style={{flexDirection: "row", borderBottomWidth: 1, borderColor: "#afaeae"}}>

            <Text style={{ paddingTop: 30, paddingBottom: 10, fontSize: 17, color: "#afaeae" }}>Phone</Text>

            <Text style={{ paddingTop: 30, textAlign: "right" , fontSize: 17, width: 280}}>{data.profile.phone}</Text>

          </View>

          <ServiceDisplay/>

          <View style={{alignSelf: "center", paddingTop: 10, paddingBottom: 45}}>
            <CustomButton text="Logout" onPress={userLogout}/>
          </View>

        </View>

      </ScrollView>
    );
  }
  else {
    return(
      <View>

      </View>
    );
  }
}

export default ProfileScreen;