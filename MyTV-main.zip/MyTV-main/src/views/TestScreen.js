import React from 'react';
import { StyleSheet, Text, View } from 'react-native';

function TestScreen() {
    
    return (
        <View>
            <Text>Hey</Text>
        </View>
    );
}

export default TestScreen;

const style = StyleSheet.create({

})
