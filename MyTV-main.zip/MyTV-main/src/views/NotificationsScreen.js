import { StatusBar } from 'expo-status-bar';
import React from 'react';
import { useState, useCallback } from 'react';
import { useRoute } from '@react-navigation/native';
import { StyleSheet, Text, View, SafeAreaView, useWindowDimensions, ScrollView, Pressable, Image } from 'react-native';
import CustomButton from '../components/button.js';
import { Dropdown } from 'react-native-element-dropdown';
import { Searchbar, Button, Card, Title, Paragraph, Portal, Modal } from 'react-native-paper';
import { Entypo } from '@expo/vector-icons';
import { useFocusEffect } from '@react-navigation/native';
import { getAuth } from "firebase/auth";
import { getDatabase, ref, child, get, remove, update, set, push } from "firebase/database";
import { TabView, TabBar } from 'react-native-tab-view';
import styles from '../styling/NotificationsScreen.style.js';

function NotificationsScreen() {

    //
    // Firebase config
    //
    const auth = getAuth();
    let uid = auth.currentUser.uid;
    const dbRef = ref(getDatabase());
    const route = useRoute();

    var services = route.params.services


    // Hooks
    const [netflixNotificationData, setNetflixNotificationData] = useState([]);

    // Hulu Hooks
    const [huluNotificationData, setHuluNotificationData] = useState([]);

    //HBO Hooks
    const [hboNotificationData, setHBONotificationData] = useState([]);

    // Disney Hook
    const [disneyNotificationData, setDisneyNotificationData] = useState([]);

    const [index, setIndex] = useState(0);
    const [routes, setRoutes] = useState(() => {
        if(services.length == 1) {
            return [{ key: 'first', title: services[0] }]
        }
    
        else if(services.length == 2) {
            return [
                { key: 'first', title: services[0] },
                { key: 'second', title: services[1] }
            ]
        }
    
        else if(services.length == 3) {
            return [
                { key: 'first', title: services[0] },
                { key: 'second', title: services[1] },
                { key: 'third', title: services[2] }
            ]
        }
    
        else if(services.length == 4) {
            return [
                { key: 'first', title: services[0] },
                { key: 'second', title: services[1] },
                { key: 'third', title: services[2] },
                { key: 'fourth', title: services[3] }
            ]
        } else {
            return[
                { key: 'fifth', title: "Notifications"}
            ]
        }
    }); 

    const layout = useWindowDimensions();

    //
    // Loading API data when screen is launched
    //
    useFocusEffect(
            useCallback(() => {
                get(child(dbRef, `users/${uid}/services`)).then((snapshot) => {
                    if (snapshot.exists()) {
                        let data = snapshot.val();
                        if(services.includes("Disney")) {
                            if(data.Disney.notifications){
                                setDisneyNotificationData(Object.values(data.Disney.notifications))
                            }
                        }

                        if(services.includes("Netflix")) {
                            if(data.Netflix.notifications){
                                setNetflixNotificationData(Object.values(data.Netflix.notifications))
                            }
                        }

                        if(services.includes("HBO")) {
                            if(data.HBO.notifications){
                                setHBONotificationData(Object.values(data.HBO.notifications))
                            }
                        }

                        if(services.includes("Hulu")) {
                            if(data.Hulu.notifications){
                                setHuluNotificationData(Object.values(data.Hulu.notifications))
                            }
                        }

                    } else {
                        console.log("No data available");
                    }
                    }).catch((error) => {
                      console.error(error);
                });

            }, [])
    );

    //
    // Custom component
    //
    function Display(props) {

        if(props.thisService == "Hulu") {
            if(huluNotificationData.length > 0) {
                return (
                    huluNotificationData.map((element) => {
                        return(
                            <View key={element.title} style={styles.NotifView}>
                                <Text style={styles.NotifText}><Text style={{fontWeight: 'bold'}}>{element.title}</Text> has left Hulu!</Text>
                                <View style={styles.NotifBorder}/>
                            </View>
                        );
                    })
                );
            } else {
                return (
                    <View style={{paddingTop: '70%'}}>
                        <Text style={{fontSize: 18, textAlign: "center",}}>No notifications at this time!</Text>
                    </View>
                );
            }
        }

        if(props.thisService == "HBO") {
            if(hboNotificationData.length > 0) {
                return (
                    hboNotificationData.map((element) => {
                        return(
                            <View key={element.title} style={styles.NotifView}>
                                <Text style={styles.NotifText}><Text style={{fontWeight: 'bold'}}>{element.title}</Text> has left HBO!</Text>
                                <View style={styles.NotifBorder}/>
                            </View>
                        );
                    })
                );
            } else {
                return (
                    <View style={{paddingTop: '70%'}}>
                        <Text style={{fontSize: 18, textAlign: "center",}}>No notifications at this time!</Text>
                    </View>
                );
            }
        }

        if(props.thisService == "Netflix") {
            if(netflixNotificationData.length > 0) {
                return (
                    netflixNotificationData.map((element) => {
                        return(
                            <View key={element.title} style={styles.NotifView}>
                                <Text style={styles.NotifText}><Text style={{fontWeight: 'bold'}}>{element.title}</Text> has left Netflix!</Text>
                                <View style={styles.NotifBorder}/>
                            </View>
                        );
                    })
                );
            } else {
                return (
                    <View style={{paddingTop: '70%'}}>
                        <Text style={{fontSize: 18, textAlign: "center",}}>No notifications at this time!</Text>
                    </View>
                );
            }
        }

        if(props.thisService == "Disney+") {
            if(disneyNotificationData.length > 0) {
                return (
                    disneyNotificationData.map((element) => {
                        return(
                            <View key={element.title} style={styles.NotifView}>
                                <Text style={styles.NotifText}><Text style={{fontWeight: 'bold'}}>{element.title}</Text> has left Disney!</Text>
                                <View style={styles.NotifBorder}/>
                            </View>
                        );
                    })
                );
            } else {
                return (
                    <View style={{paddingTop: '70%'}}>
                        <Text style={{fontSize: 18, textAlign: "center",}}>No notifications at this time!</Text>
                    </View>
                );
            }
        }
    }


    const FirstRoute = (props) => (
        <ScrollView style={{paddingTop: 10}}>
                <Display thisService={services[0]}/>
        </ScrollView>
    );

    const SecondRoute = (props) => (
        <ScrollView style={{paddingTop: 10}}>
                <Display thisService={services[1]}/>
        </ScrollView>
    );

    const ThirdRoute = (props) => (
        <ScrollView style={{paddingTop: 10}}>
                <Display thisService={services[2]}/>
        </ScrollView>
    );

    const FourthRoute = (props) => (
        <ScrollView style={{paddingTop: 10}}>
            <Display thisService={services[3]}/>
        </ScrollView>
    );

    const FifthRoute = (props) => (
        <View style={{alignItems: "center"}}>
            <Text style={{ paddingTop: "50%", fontWeight: "bold", fontSize: 18}}>No Services Connected!</Text>
        </View>
    );


    //
    // Custom scene render to pass props properly
    //
    const renderScene = ({ route }) => {
        switch (route.key) {
        case 'first':
            return <FirstRoute/>;
        case 'second':
            return <SecondRoute/>;
        case 'third':
            return <ThirdRoute/>;
        case 'fourth':
            return <FourthRoute/>;
        case 'fifth':
            return <FifthRoute/>;
        default:
            return null;
        }
    };

    const renderTabBar = props => (
        <TabBar
            {...props}
            indicatorStyle={{ backgroundColor: 'white' }}
            style={{ backgroundColor: 'black' }}
        />
    );
    
    return (
        <TabView  
            renderTabBar={renderTabBar}
            navigationState={{ index, routes }}
            renderScene={renderScene}
            onIndexChange={setIndex}
            initialLayout={{ width: layout.width }}
        />
    );
}

export default NotificationsScreen;