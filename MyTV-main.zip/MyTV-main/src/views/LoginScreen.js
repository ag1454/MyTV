import { StatusBar } from 'expo-status-bar';
import React from 'react';
import { Text, View, SafeAreaView, Alert, Pressable } from 'react-native';
import { Button, TextInput, Dialog, Paragraph } from 'react-native-paper';
import { getAuth, signInWithEmailAndPassword, sendPasswordResetEmail } from 'firebase/auth';
import { LogBox } from 'react-native';
import CustomButton from '../components/button.js';
import { getDatabase, ref, child, get } from "firebase/database";
import styles from '../styling/LoginScreen.style.js';
import { generate } from '../functions/generate.js';
import { useToggleIconChange } from '../functions/TogglePassword.js';

// password toggle hook: https://amanhimself.dev/blog/show-hide-password-in-react-native-using-custom-hook/

LogBox.ignoreLogs(['Warning: Async Storage has been extracted from react-native core']);


function LoginScreen({ route, navigation }) {

    // toggle password
    const { passwordVisibility, rightIcon, handlePasswordVisibility } =
    useToggleIconChange();

    // State var for email used to login
    const [email, setEmail] = React.useState("");

    // State var for password used to login
    const [password, setPassword] = React.useState("");

    // State var for making forgot password dialog visible
    const [visible, setVisible] = React.useState(false);

    // State var for email used to reset password
    const [forgotEmail, setForgotEmail] = React.useState("");

    // Functions for dialog box
    const showDialog = () => setVisible(true);
    const hideDialog = () => setVisible(false);

    // User login function
    const userLogin = () => {
        // console.log(email);
        // console.log(password);

        if (email === "" || password === "") {
          Alert.alert('Enter email and password to login!');
        } else {
          const auth = getAuth();
          signInWithEmailAndPassword(auth, email, password)
          .then(() => {
            generate();
            navigation.navigate("mySubscriptions")
          })
          .catch((error) => {
            const errorMessage = error.message;
            Alert.alert('Incorrect Email or Password!');
            console.log(errorMessage);
          });
        }
    };

    // Sends password reset email to user email
    const forgotPassword = () => {
      console.log(forgotEmail);

      const auth = getAuth();
      sendPasswordResetEmail(auth, forgotEmail).then(() => {
          Alert.alert("Reset email sent!")
          hideDialog();
      }).catch(function(error){
          Alert.alert("Incorrect email!")
          console.log(error.message)
      });
    };

    return (
    <SafeAreaView style={styles.container}>
        
        <View style={styles.top}>
          <Text style={styles.myTV}>
            <Text style={{ fontWeight: "normal", color: "white" }}>my</Text>TV
          </Text>
        </View>


        <View style={styles.middle}>
          <TextInput
            mode="outlined"
            theme={{
              roundness: 25,
            }}
            onChangeText={email => setEmail(email)}
            style={styles.textInputs}
            placeholder="Email"/>

          <TextInput
            mode="outlined"
            theme={{
              roundness: 25,
            }}
            secureTextEntry={passwordVisibility}
            onChangeText={password => setPassword(password)}
            style={styles.textInputs}
            placeholder="Password"
            right={
              <TextInput.Icon
                icon={rightIcon}
                onPress={handlePasswordVisibility}
              />
            }
            />

            <View style={{paddingTop: 25}}>
              <CustomButton style={{paddingTop: 15}} onPress={userLogin} text="Login"/>
            </View>

            <Pressable onPress={showDialog}>
              <Text style={{paddingTop: 25}}>Forgot Password?</Text>
            </Pressable>

          <StatusBar style="auto" />
        </View>

        <Dialog visible={visible} onDismiss={hideDialog}>
              <Dialog.Title style={{paddingLeft: 55}}>Password Reset</Dialog.Title>
              <Dialog.Content>
                <Paragraph style={{paddingBottom: 15, fontSize: 14}}>Enter Email Address for MyTV Account:</Paragraph>
                <TextInput
                  mode="outlined"
                  theme={{
                    roundness: 25,
                  }}
                  onChangeText={forgotEmail => setForgotEmail(forgotEmail)}
                  style={{}}
                  placeholder="Email"/>
              </Dialog.Content>
              <Dialog.Actions>
                <Button onPress={forgotPassword}>Send Email</Button>
                <Button onPress={hideDialog}>Done</Button>
              </Dialog.Actions>
        </Dialog>

    </SafeAreaView>
    );
} 

export default LoginScreen;