import React, { useState, useRef } from 'react';
import { View, Animated, Image, ScrollView, Text } from "react-native";
import { Button, List } from 'react-native-paper';
import { Dropdown } from 'react-native-element-dropdown';
import styles from '../styling/ChangesScreen.style.js';
import CustomButton from '../components/button.js';
import { Entypo } from '@expo/vector-icons';
import { DefaultTheme, Provider as PaperProvider } from 'react-native-paper';
// base collapsible header code: https://itnext.io/react-native-collapsible-headers-explained-78584ff133d8

//
// Genres mapping for API calls
//
const genres = { 
  1: "Biography",
  2: "Film Noir",
  3: "Game Show",
  4: "Musical",
  5: "Sport",
  6: "Short",
  7: "Adult",
  12: "Adventure",
  14: "Fantasy",
  16: "Animation",
  18: "Drama",
  27: "Horror",
  28: "Action",
  35: "Comedy",
  36: "History",
  37: "Western",
  53: "Thriller",
  80: "Crime",
  99: "Documentary",
  878: "Science Fiction",
  9648: "Mystery",
  10402: "Music",
  10749: "Romance",
  10751: "Family",
  10752: "War",
  10763: "News",
  10764: "Reality",
  10767: "Talk Show"
}

const H_MAX_HEIGHT = 130;
const H_MIN_HEIGHT = 50;
const H_SCROLL_DISTANCE = H_MAX_HEIGHT - H_MIN_HEIGHT;

const theme = {
  ...DefaultTheme,
  colors: {
    ...DefaultTheme.colors,
    primary: '#99cfdf',
  },
};

function ChangesScreen({route, navigation}) {

    // header stuff
    const scrollOffsetY = useRef(new Animated.Value(0)).current;
    const headerScrollHeight = scrollOffsetY.interpolate({
      inputRange: [0, H_SCROLL_DISTANCE],
      outputRange: [H_MAX_HEIGHT, H_MIN_HEIGHT],
      extrapolate: "clamp"
    });

    // Dropdown Objects and Hooks
    const media = [
        { label: 'Movie', value: 'movie' },
        { label: 'Series', value: 'series' },
    ]
    const [value, setValue] = useState('movie');
    const [isFocus, setIsFocus] = useState(false);

    const media2 = [
      { label: 'New', value: 'new' },
      { label: 'Leaving', value: 'removed' },
    ]
    const [value2, setValue2] = useState('new');
    const [isFocus2, setIsFocus2] = useState(false);

    // Screen Hooks
    const [queryResults, SetQueryResults] = useState([]);

    // Standardizing the route.params value to be coordinated with the API value
    var service
    if(route.params.service == "Netflix"){
        service = "netflix"
    } else if(route.params.service == "HBO") {
        service = "hbo"
    } else if(route.params.service == "Hulu") {
        service = "hulu"
    } else if(route.params.service == "Disney+") {
        service = "disney"
    }

    //
    // Availability changes in the services, new or removed.
    // Includes all the changes in the last 7 days. No pagination
    //
    function changes() {

      const fetch = require('node-fetch');

      const url = 'https://streaming-availability.p.rapidapi.com/changes?' +
                  'service=' + service + '&' +
                  'country=us&' +
                  'change_type=' + value2 + '&' +
                  'type=' + value + '&' +
                  'output_language=en';

      const options = {
      method: 'GET',
      headers: {
          'X-RapidAPI-Key': '1b11125fe6msh8a001dd71a23db7p15705cjsn96bb6fc93404',
          'X-RapidAPI-Host': 'streaming-availability.p.rapidapi.com'
      }
      };

      fetch(url, options)
          .then(res => res.json())
          .then(json => {
              console.log("Changes call size: " + json.results.length)

              // Sort Results based on genre map at top of file, in ascending order (genre 1 first....genre 10767 last)
              let sortedResults = json.results.sort(
                  (p1, p2) => (p1.genres[0] > p2.genres[0]) ? 1 : (p1.genres[0] < p2.genres[0]) ? -1 : 0)

              SetQueryResults(sortedResults)

          })
          .catch(err => console.error('error:' + err));
    }  


    //
    // Function to display the results of the query
    //
    function DisplayResults(props) {
        if(filter(props.genre).length > 0) {
            return (
              <PaperProvider theme={theme}>
                <>
                <List.Accordion
                  title={genres[props.genre]}
                  left={props => <List.Icon {...props} icon="book"/>}>
                  {filter(props.genre).map((element) => {
                    return (
                      <View key={element.title}>
                        <List.Item style={styles.elementText} title={element.title}/>
                      </View>  
                    );
                  })}
                </List.Accordion>
                </>
              </PaperProvider>
            );
        } else {
            return null;
        }
    }

    //
    // Function to filter results based on genre
    //
    function filter(genre) {
        var results = queryResults.filter(obj => {
            return obj.genres[0] == genre;
        })

        return results;
    }

  return (
    <View style={{ flex: 1 }}>
      <ScrollView 
        onScroll={Animated.event([
            { nativeEvent: { contentOffset: { y: scrollOffsetY } } }
          ], {useNativeDriver: false})}
        scrollEventThrottle={16}>
        
        <View style={{paddingTop: H_MAX_HEIGHT, backgroundColor: 'white'}}>
                <DisplayResults genre="1"/>
                <DisplayResults genre="2"/>
                <DisplayResults genre="3"/>
                <DisplayResults genre="4"/>
                <DisplayResults genre="5"/>
                <DisplayResults genre="6"/>
                <DisplayResults genre="7"/>
                <DisplayResults genre="12"/>
                <DisplayResults genre="14"/>
                <DisplayResults genre="16"/>
                <DisplayResults genre="18"/>
                <DisplayResults genre="27"/>
                <DisplayResults genre="28"/>
                <DisplayResults genre="35"/>
                <DisplayResults genre="36"/>
                <DisplayResults genre="37"/>
                <DisplayResults genre="53"/>
                <DisplayResults genre="80"/>
                <DisplayResults genre="99"/>
                <DisplayResults genre="878"/>
                <DisplayResults genre="9648"/>
                <DisplayResults genre="10402"/>
                <DisplayResults genre="10749"/>
                <DisplayResults genre="10751"/>
                <DisplayResults genre="10752"/>
                <DisplayResults genre="10763"/>
                <DisplayResults genre="10764"/>
                <DisplayResults genre="10767"/>
        </View>
      </ScrollView>

        <Animated.View
        style={{
            position: "absolute",
            left: 0,
            right: 0,
            top: 0,
            height: headerScrollHeight,
            width: "100%",
            overflow: "hidden",
            zIndex: 999,
            borderBottomColor: "#EFEFF4",
            borderBottomWidth: 2,
            padding: 10,
            backgroundColor: "lightgrey"}}>
            <Text style={styles.descText}>Filter results:</Text>

        <View style={{flexDirection: 'row'}}>
          <View style={{width: '35%'}}>
            <Dropdown
                style={[styles.dropdownCategory, isFocus && { borderColor: 'blue' }]}
                placeholderStyle={{ fontSize: 16 }}
                selectedTextStyle={{ fontSize: 16 }}
                inputSearchStyle={{ height: 40, fontSize: 16 }}
                iconStyle={styles.iconStyle}
                data={media}
                maxHeight={300}
                labelField="label"
                valueField="value"
                placeholder={!isFocus ? 'Movie' : '...'}
                value={value}
                onFocus={() => setIsFocus(true)}
                onBlur={() => setIsFocus(false)}
                onChange={item => {
                    setValue(item.value);
                    setIsFocus(false);
                    SetQueryResults([]);
                }}/>
          </View>
          
          <View style={{width: '35%'}}>
            <Dropdown
                style={[styles.dropdownMedia, isFocus2 && { borderColor: 'blue' }]}
                placeholderStyle={{ fontSize: 16 }}
                selectedTextStyle={{ fontSize: 16 }}
                inputSearchStyle={{ height: 40, fontSize: 16 }}
                iconStyle={styles.iconStyle}
                data={media2}
                maxHeight={300}
                labelField="label"
                valueField="value"
                placeholder={!isFocus ? 'New' : '...'}
                value={value2}
                onFocus={() => setIsFocus(true)}
                onBlur={() => setIsFocus(false)}
                onChange={item => {
                    setValue2(item.value);
                    setIsFocus2(false);
                    SetQueryResults([]);
                }}/>
          </View>

            <Button mode="contained" style={styles.button} buttonColor='black' onPress={() => changes()}>
              <Entypo name="magnifying-glass" size={22} color="white" style={{alignSelf: 'center'}}/>
            </Button>
          </View>
      </Animated.View>
    </View>
  )
}

export default ChangesScreen;