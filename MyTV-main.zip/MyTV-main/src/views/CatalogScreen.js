import React, { useState } from 'react';
import { Text, View, ScrollView, Pressable } from 'react-native';
import { Card, Title, IconButton } from 'react-native-paper';
import { Dropdown } from 'react-native-element-dropdown';
import { useRoute } from '@react-navigation/native';
import { getDatabase, push, ref } from "firebase/database";
import { getAuth } from "firebase/auth";
import styles from '../styling/CatalogScreen.style.js';

// Array for storing the titles of a page of API data
const titleArray = [
    { id: 0, title: "test entry", genres: []},
    { id: 1, title: "test entry", genres: []},
    { id: 2, title: "test entry", genres: []},
    { id: 3, title: "test entry", genres: []},
    { id: 4, title: "test entry", genres: []},
    { id: 5, title: "test entry", genres: []},
    { id: 6, title: "test entry", genres: []},
    { id: 7, title: "test entry", genres: []}
]

// Genre array that correlates to API values
const genres = [
    { label: 'Biography', value: '1' },
    { label: 'Musical', value: '4' },
    { label: 'Sport', value: '5' },
    { label: 'Adult', value: '7' },
    { label: 'Adventure', value: '12' },
    { label: 'Fantasy', value: '14' },
    { label: 'Animation', value: '16' },
    { label: 'Drama', value: '18' },
    { label: 'Horror', value: '27' },
    { label: 'Action', value: '28' },
    { label: 'Comedy', value: '35' },
    { label: 'History', value: '36' },
    { label: 'Western', value: '37' },
    { label: 'Thriller', value: '53' },
    { label: 'Crime', value: '80' },
    { label: 'Documentary', value: '99' },
    { label: 'Science Fiction', value: '878' },
    { label: 'Music', value: '10402' },
    { label: 'Romance', value: '10749' },
    { label: 'Family', value: '10751' },
    { label: 'War', value: '10752' },
    { label: 'News', value: '10763' },
    { label: 'Reality', value: '10764' },
    { label: 'Talk Show', value: '10767' },
    { label: 'Film Noir', value: '2' },
    { label: 'Game Show', value: '3' },
    { label: 'Short', value: '6' },
]

// Correlates to API values
const media = [
    { label: 'Movie', value: 'movie' },
    { label: 'Series', value: 'series' },
]

const page = {
     total: 0,
     current: 1
}


function CatalogScreen({navigation}) {

    const route = useRoute();

    // console.log(titleArray);

    const [state, setState] = useState(false)
    const [value, setValue] = useState(null);
    const [isFocus, setIsFocus] = useState(false);
    const [value2, setValue2] = useState(null);
    const [isFocus2, setIsFocus2] = useState(false);
    const [value3, setValue3] = useState(null);
    const [isFocus3, setIsFocus3] = useState(false);
    const [index, setIndex] = useState(1);
    
    //
    // Render lables based on focus
    //
    const renderLabel2 = () => {
        if (value2 || isFocus2) {
          return (
            <Text style={[styles.label, isFocus && { color: 'blue' }]}>
              Genre
            </Text>
          );
        }
        return null;
    };

    //
    // Render lables based on focus
    //
    const renderLabel3 = () => {
        if (value3 || isFocus3) {
          return (
            <Text style={[styles.label, isFocus && { color: 'blue' }]}>
              Media
            </Text>
          );
        }
        return null;
    };

    //
    // Pulls data from API based on user entry and sets the state of the page
    //
    function testState() {

        // Page is empty OR new search || Next Page is pressed
        if ((state == false) || (page.current > 1) || (state == true && page.current == 1)) {

                // Re-initiliazes current page for new searches
                if (state == false) {
                    page.current = 1;
                }

                var service = route.params.service;
                var genre = value2;
                var media = value3;
                console.log(service + " " + page.current)

                // Resetting titleArray
                titleArray.length = 0;

                const fetch = require('node-fetch');

                // URL to get Data from API based on what is entered
                const url = 'https://streaming-availability.p.rapidapi.com/search/basic?country=us&service=' + service +
                            '&type=' + media +
                            '&page=' + page.current +
                            '&genre=' + genre + 
                            '&output_language=en&language=en';
            
                // Getting API key
                const options = {
                method: 'GET',
                headers: {
                    'X-RapidAPI-Key': '1b11125fe6msh8a001dd71a23db7p15705cjsn96bb6fc93404',
                    'X-RapidAPI-Host': 'streaming-availability.p.rapidapi.com'
                }
                };
            
                fetch(url, options)
                    .then(res => res.json())
                    
                    .then(json => {
                        // Pushing each entry of data pulled from API into the titleArray
                        page.total = json.total_pages;
                        console.log(page.total);
                        var i = 1;
                        for(let data of json.results) {
                        titleArray.push({
                            id: i,
                            title: data.title,
                            genres: data.genres 
                        })
                        i++;
                        }
                        console.log(titleArray);
                        // Setting state to true to display the titleArray
                        setState(true);

                        setIndex(page.current);
                    })    
                    .catch(err => console.error('error:' + err));
        }

    }
    
    //
    // Function to switch to next page of data
    //
    function nextPage() {

        if(page.current < page.total) {
            page.current = page.current + 1;
            // console.log(page.current);
            testState();
        } else {
            console.log("No more pages");
        }
    }

    //
    // Function to switch to previous page of data
    //
    function previousPage() {
        page.current = page.current - 1;
        console.log(page.current);
        if(page.current == 1) {
            // console.log("test")
            testState();
        } else {
            testState();
        }
    }

    //
    // Function to render the next page button
    //
    function populateNext() {
        // console.log("total pages: " + page.total)
        if(page.total > 1 && page.current != page.total) {
            return (
            <Pressable onPress={() => { nextPage()}}>
                <Text style={{ marginLeft: 15, fontSize: 18, textDecorationLine: 'underline'}}>Next</Text>
            </Pressable>
            );
        }
        return null
    }

    //
    // Function to render the previous page button
    //
    function populatePrevious() {
        if(page.current > 1) {
            return (
                <Pressable onPress={() => { previousPage()}}>
                    <Text style={{ marginRight: 15, fontSize: 18, textDecorationLine: 'underline'}}>Previous</Text>
                </Pressable>
            );
        }
        return null;
    }

    //
    // Function to add title to a users following/titles array in Firebase
    //
    function followTitle(title) {
        console.log(title);
        const db = getDatabase();
        const auth = getAuth();
    
        const uid = auth.currentUser.uid;

        push(ref(db, `users/${uid}/following/titles`), {
            "title": title
        });
    }

    //
    // Function to populate data based on titleArray
    //
    function populateData() {
        
        return titleArray.map((entry) => {            
            return (
                <Card key={entry.id} style={styles.cardContainer}>
                        <Card.Content style={{flexDirection: "row"}}>
                            <Title style={{fontSize: 16, width: "80%"}}>{entry.title}</Title>
                            <Pressable onPress={() => followTitle(entry.title)} style={{paddingTop: 7.5, width: "20%"}}>
                                <Text style={{fontSize: 16, textDecorationLine: "underline"}}>Follow</Text>
                            </Pressable>
                        </Card.Content>
                </Card>
            );
        })
    }


    //
    // RENDERS:
    //

    // User first gets to the myCatalog Page
    if (state == false) {
      return (
          <View>
              <View style={styles.row}>

                  <View style={styles.container}>
                      {renderLabel2()}
                      <Dropdown
                      style={[styles.dropdownGenre, isFocus2 && { borderColor: 'blue' }]}
                      placeholderStyle={styles.placeholderStyle}
                      selectedTextStyle={styles.selectedTextStyle}
                      inputSearchStyle={styles.inputSearchStyle}
                      iconStyle={styles.iconStyle}
                      data={genres}
                      search
                      maxHeight={300}
                      labelField="label"
                      valueField="value"
                      placeholder={!isFocus2 ? 'Genre' : '...'}
                      searchPlaceholder="Search..."
                      value={value2}
                      onFocus={() => setIsFocus2(true)}
                      onBlur={() => setIsFocus2(false)}
                      onChange={item => {
                          setValue2(item.value);
                          setIsFocus2(false);
                      }}/>
                  </View> 

                  <View style={styles.container}>
                      {renderLabel3()}
                      <Dropdown
                      style={[styles.dropdown, isFocus3 && { borderColor: 'blue' }]}
                      placeholderStyle={styles.placeholderStyle}
                      selectedTextStyle={styles.selectedTextStyle}
                      inputSearchStyle={styles.inputSearchStyle}
                      iconStyle={styles.iconStyle}
                      data={media}
                      maxHeight={300}
                      labelField="label"
                      valueField="value"
                      placeholder={!isFocus3 ? 'Media' : '...'}
                      value={value3}
                      onFocus={() => setIsFocus3(true)}
                      onBlur={() => setIsFocus3(false)}
                      onChange={item => {
                          setValue3(item.value);
                          setIsFocus3(false);
                      }}/>
                  </View>

                  <View style={{}}>
                        <IconButton
                          icon="magnify"
                          iconColor="black"
                          size={30}
                          style={{width: 50, height: 50, marginTop: 12, marginLeft: 0}}
                          onPress={() => testState()}
                        />
                  </View>
              </View>

              <View style={{paddingTop: "50%", alignItems: "center"}}>
                <Text style={{alignSelf: "center", fontSize: 18, fontWeight: "bold"}}>Find Titles by Genre Above!</Text>
              </View>
          </View>
      );
  }

  // User has made a search call
  if(state == true) {
      return (
        <View>
            <View style={styles.row}>

                <View style={styles.container}>
                    {renderLabel2()}
                    <Dropdown
                    style={[styles.dropdownGenre, isFocus2 && { borderColor: 'blue' }]}
                    placeholderStyle={styles.placeholderStyle}
                    selectedTextStyle={styles.selectedTextStyle}
                    inputSearchStyle={styles.inputSearchStyle}
                    iconStyle={styles.iconStyle}
                    data={genres}
                    search
                    maxHeight={300}
                    labelField="label"
                    valueField="value"
                    placeholder={!isFocus2 ? 'Genre' : '...'}
                    searchPlaceholder="Search..."
                    value={value2}
                    onFocus={() => setIsFocus2(true)}
                    onBlur={() => setIsFocus2(false)}
                    onChange={item => {
                        setValue2(item.value);
                        setIsFocus2(false);
                        setState(false);
                    }}/>
                </View> 

                <View style={styles.container}>
                    {renderLabel3()}
                    <Dropdown
                    style={[styles.dropdown, isFocus3 && { borderColor: 'blue' }]}
                    placeholderStyle={styles.placeholderStyle}
                    selectedTextStyle={styles.selectedTextStyle}
                    inputSearchStyle={styles.inputSearchStyle}
                    iconStyle={styles.iconStyle}
                    data={media}
                    maxHeight={300}
                    labelField="label"
                    valueField="value"
                    placeholder={!isFocus3 ? 'Media' : '...'}
                    value={value3}
                    onFocus={() => setIsFocus3(true)}
                    onBlur={() => setIsFocus3(false)}
                    onChange={item => {
                        setValue3(item.value);
                        setIsFocus3(false);
                        setState(false);
                    }}/>
                </View>

                <View style={{}}>
                      <IconButton
                        icon="magnify"
                        iconColor="black"
                        size={30}
                        style={{width: 50, height: 50, marginTop: 12, marginLeft: 0}}
                        onPress={() => testState()}
                      />
                </View>
            </View>

            <ScrollView style={styles.scrollContainer}>
                {populateData()}
            </ScrollView>

            <View style={{paddingTop: 10, flexDirection: "row", justifyContent: "center"}}>
                    {populatePrevious()}
                    {populateNext()}
            </View>
        </View>
      );
  }
}

export default CatalogScreen;