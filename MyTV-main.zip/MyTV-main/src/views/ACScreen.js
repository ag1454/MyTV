import { StatusBar } from 'expo-status-bar';
import React from 'react';
import { Text, View, SafeAreaView, Alert } from 'react-native';
import { TextInput } from 'react-native-paper';
import { db } from '../../firebase-config'; 
import { ref, set } from 'firebase/database';
import { getAuth, createUserWithEmailAndPassword, signOut, signInWithEmailAndPassword} from "firebase/auth";
import CustomButton from '../components/button.js';
import styles from '../styling/ACScreen.style.js';
import { useToggleIconChange } from '../functions/TogglePassword.js';
// password toggle hook: https://amanhimself.dev/blog/show-hide-password-in-react-native-using-custom-hook/

// anemailorsuch@gmail.com
// testing

function createAccount(strEmail, strPassword, strFname, strLname, strPhone, navigation) {
  const auth = getAuth();
  createUserWithEmailAndPassword(auth, strEmail, strPassword)//creates account
  .then((userCredential) => {
    // Signed in 
    const user = userCredential.user;
    // ...
    const uid = user.uid;

    navigation.navigate("Login Screen");

    set(ref(db, 'users/' + uid + '/profile'), {//sends user information to database
      firstName: strFname,
      lastName: strLname,
      email: strEmail,
      password: strPassword,
      phone: strPhone

    }).catch((error) => {
      console.log(error.code);
      Alert.alert("Could not create account!")
    });

  }).catch((error) => {
    const errorCode = error.code;
    const errorMessage = error.message;
    console.log("Error code: " + errorCode)
    console.log("Error Message: " + errorMessage)
    Alert.alert("Could not create account!")
    // ..
  });
}

function ACScreen({route, navigation}) {
    let isPassword = true;
    const [email, setEmail] = React.useState("");
    const [Fname, setFname] = React.useState("");
    const [Lname, setLname] = React.useState("");
    const [phone, setPhone] = React.useState("");
    const [password, setPassword] = React.useState("");
    const [Cpassword, setCpassword] = React.useState("");

    const { passwordVisibility, rightIcon, handlePasswordVisibility } =
    useToggleIconChange();

    const createPressed = () => {
      if(!isPassword){//catches two types of password errors
          console.log("Passwords do not match");
      }
      else{
          createAccount(email, password, Fname, Lname, phone, navigation);
      }
    }

    return (
    <SafeAreaView style={styles.container}>
        <View style={styles.top}>
          <Text style={styles.text}>Create Account</Text>
            <View style={{ alignItems: "center", paddingTop: 20}}>
            <TextInput
              mode="outlined"
              theme={{
                roundness: 25,
              }}
              style={styles.textInputs}
              placeholder="Email"
              onChangeText={email => setEmail(email)}
              value={email}    />

            <TextInput
              mode="outlined"
              theme={{
                roundness: 25,
              }}
              style={styles.textInputs}
              placeholder="First Name"
              onChangeText={Fname => setFname(Fname)}
              value = {Fname}/>

            <TextInput
              mode="outlined"
              theme={{
                roundness: 25,
              }}
              style={styles.textInputs}
              placeholder="Last Name"
              onChangeText={Lname => setLname(Lname)}
              value = {Lname}/>

            <TextInput
              mode="outlined"
              theme={{
                roundness: 25,
              }}
              style={styles.textInputs}
              placeholder="Phone"
              onChangeText={phone => setPhone(phone)}
              value = {phone}
              returnKeyType="done"
              keyboardType='numeric'/>

            <View style={styles.inputContainer}>
              <TextInput
                mode="outlined"
                theme={{
                  roundness: 25,
                }}
                secureTextEntry={passwordVisibility}
                style={styles.textInputs}
                placeholder="Password"
                onChangeText={password => setPassword(password)}
                value = {password}
                right={
                  <TextInput.Icon
                    icon={rightIcon}
                    onPress={handlePasswordVisibility}
                  />
                }/>
            </View>

            <View style={{paddingTop: 30}}>
              <CustomButton onPress={createPressed} text="Create Account"/>
            </View>

            <StatusBar style="auto" />
          </View>
        </View>
    </SafeAreaView>
    );
}

export default ACScreen;