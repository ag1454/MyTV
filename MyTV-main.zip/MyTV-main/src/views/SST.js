import React, {useState, useCallback } from 'react';
import { Text, View, SafeAreaView, ScrollView, useWindowDimensions, Pressable, Image } from 'react-native';
import { Avatar, Button, DataTable, Surface, IconButton, Portal, Modal } from "react-native-paper";
import { TabView, TabBar } from 'react-native-tab-view';
import { useRoute } from '@react-navigation/native';
import { getAuth } from "firebase/auth";
import { getDatabase, ref, child, get, remove, update } from "firebase/database";
import { payment } from '../functions/payment.js';
import { useFocusEffect } from '@react-navigation/native';
import CustomButton from '../components/button.js';
import { useLayoutEffect } from 'react';
import styles from '../styling/SST.style.js';
// Tabs: https://www.npmjs.com/package/react-native-tab-view
// icons: https://icons.expo.fyi/

//
// Service page
//
function SST({ navigation }) {

  // Hooks
  const [followingData, setFollowingData] = useState([]);
  const [notificationData, setNotificationData] = useState([]);
  const [paymentData, setPaymentData] = useState({});
  const [index, setIndex] = useState(0);
  const [posterData, setPosterData] = useState([]);
  const [visible, setVisible] = React.useState(false);
  const [routes] = useState([
      { key: 'first', title: 'Payment' },
      { key: 'second', title: 'Following' },
  ]); 


  const layout = useWindowDimensions();

  // Current user auth and database reference
  const auth = getAuth();
  let uid = auth.currentUser.uid;
  const dbRef = ref(getDatabase());
  const route = useRoute();

  //
  // Setup header options
  //
  useLayoutEffect(() => {
      navigation.setOptions({
        headerTitle: () => <Text style={{color: "black", fontWeight: "bold", fontSize: 25}}><Text style={{fontWeight: "normal", color: "white", fontSize: 25}}>my</Text>{route.params.service}</Text>,
        headerBackTitle: "",
        headerStyle: {backgroundColor: "#55b0ca"},
        headerTitleStyle: { fontSize: 24, color: "black" },
        headerRight: () => (
          <IconButton
            icon="magnify"
            iconColor="black"
            size={30}
            style={{width: 30, height: 30}}
            onPress={() => navigation.navigate("Search Screen", {service: route.params.service})}
          />
        ),
      })

  }, [navigation])

  // Set image
  let image
  if(route.params.service == "Netflix") {
    image = <Avatar.Image size={100} source={require('../../assets/netflixlogo.jpg')} />
  } else if(route.params.service == "HBO") {
    image = <Avatar.Image size={100} source={require('../../assets/HBOSmall.png')} />
  } else if(route.params.service == "Hulu") {
    image = <Avatar.Image size={100} source={require('../../assets/sstHuluLogo.png')} />
  } else if(route.params.service == "Disney+") {
    image = <Avatar.Image size={100} source={require('../../assets/disneylogo2.jpg')} />
  }


  //
  // Get the data required for the screen to render
  //
  useFocusEffect(
    useCallback(() => {

        get(child(dbRef, `users/${uid}/services/${route.params.service}`)).then((snapshot) => {
            if (snapshot.exists()) {
              let data = snapshot.val();
              setPaymentData(payment(route.params.service, data.subscription));

              if(data.notifications) {
                setNotificationData(data.notifications);
              }

              if(data.following) {
                setFollowingData(Object.keys(data.following));
                setPosterData([]);

                // for posterData
                for (const property in data.following) {
                  get(child(dbRef, `titleLibrary/${data.following[property].imdbID}`)).then((snapshot) => {
                    if (snapshot.exists()) {
                      let data1 = snapshot.val();
                      setPosterData(posterData => [...posterData, data1]);
                    } else {
                      console.log("No data available");
                    }
                    }).catch((error) => {
                  console.error(error);
                });
                }
              }
            } else {
                console.log("No data available");
            }
            }).catch((error) => {
              console.error(error);
        });

    }, [])
  );
  

  //
  // Component to render payment data with a maximum of the three latest payments
  //
  function PopulatePaymentData() {
    
    if(paymentData.payments && paymentData.payments.length == 1) {
      return (
        paymentData.payments.map(element => {
          return (
            <DataTable.Row key={element.date}>
            <DataTable.Cell>{element.date}</DataTable.Cell>
            <DataTable.Cell numeric>{element.price}</DataTable.Cell>
            </DataTable.Row>
          );
        })
      );
    }
    else if(paymentData.payments && paymentData.payments.length == 2) {
      return (
        paymentData.payments.map(element => {
          return (
            <DataTable.Row key={element.date}>
            <DataTable.Cell>{element.date}</DataTable.Cell>
            <DataTable.Cell numeric>{element.price}</DataTable.Cell>
            </DataTable.Row>
          );
        })
      );
    }
    else if(paymentData.payments && paymentData.payments.length == 3) {
      return (
        paymentData.payments.map(element => {
          return (
            <DataTable.Row key={element.date}>
            <DataTable.Cell>{element.date}</DataTable.Cell>
            <DataTable.Cell numeric>{element.price}</DataTable.Cell>
            </DataTable.Row>
          );
        })
      );
    }
    else if(paymentData.payments && paymentData.payments.length > 3) {
      return (
        paymentData.payments.slice(paymentData.payments.length-3, paymentData.payments.length).map(element => {
          return (
            <DataTable.Row key={element.date}>
            <DataTable.Cell>{element.date}</DataTable.Cell>
            <DataTable.Cell numeric>{element.price}</DataTable.Cell>
            </DataTable.Row>
          );
        })
      );
    } else {
      return (
        <Text></Text>
      )
    }

  }

  //
  // Component to render follow data
  //
  function PopulateFollowingData() {
    if(followingData.length == 0) {
        return(
            <View style={{alignItems: 'center', paddingTop: "40%"}}>
                <Text style={{ fontSize: 22, fontWeight: "bold"}}>Follow Titles Below!</Text> 
                <CustomButton text="Search" onPress={() => navigation.navigate("Search Screen", {service: route.params.service})}/>
            </View>
        );
    } else {
      return(
        posterData.map((val, i) => {
          return (
            <View key={i} style={styles.followContainer}>
              <Image style={styles.poster} source={{uri: `${val.poster}`}}/>

              <View style={styles.followInfo}>
                <Text style={{textAlign: 'center', fontWeight: "Bold", paddingTop: 10}}>{val.title} ({val.year})</Text>

                <Text style={{fontWeight: 'bold',  paddingTop: 10, textAlign: 'center'}}>Cast:</Text>
                <Text style={{textAlign: 'center'}}>{val.cast[0]}, {val.cast[1]}, {val.cast[2]}</Text>

                <Text style={{fontWeight: 'bold',  paddingTop: 10, textAlign: 'center'}}>Director:</Text>
                <Text style={{textAlign: 'center'}}>{val.significants[0]}</Text>
                <View style={{paddingTop: 12}}>
                <Button key={i} mode="contained" style={{justifyContent: 'center', alignSelf: 'center', padding: '2%', backgroundColor: '#99cfdf', margin: '8%'}} onPress={() => unfollow(val.title)}>
                  Unfollow
                </Button>
                </View>
              </View>
            </View>
          );
        })
      );
    }
  }

  //
  // Function to unfollow the title in the database
  //
  function unfollow(title) {
    remove(child(dbRef, `users/${uid}/services/${route.params.service}/following/${title}`)).then(
      get(child(dbRef, `users/${uid}/services/${route.params.service}/following`)).then((snapshot) => {
        if (snapshot.exists()) {
            let data = snapshot.val();
            setFollowingData(Object.keys(data));
            setPosterData([]);
            for (const property in data) {
              get(child(dbRef, `titleLibrary/${data[property].imdbID}`)).then((snapshot) => {
                if (snapshot.exists()) {
                  let data1 = snapshot.val();

                  setPosterData(posterData => [...posterData, data1])
                } else {
                  console.log("No data available");
                }
                }).catch((error) => {
              console.error(error);
            });
            }
        } else {
          setFollowingData([]);
          setPosterData([]);
        }
        }).catch((error) => {
        //console.error(error);
      })
    );
  }

  //
  // Function to change status of service from active to inactive
  //
  function suspend() {

    // console.log(paymentData.status)
    update(child(dbRef, `users/${uid}/services/${route.params.service}/subscription`), {
        "status": "inactive"
    }).then(() => {

      navigation.navigate("mySubscriptions");
    })
  }

  // 
  // function to change visibility of the dialog box
  //
  function changeVisibility() {
      if(visible == false) {
          setVisible(true);
      } else {
          setVisible(false);
      }
  }

  //
  // Dialog Box 
  //
  function DialogBox() {
    if(visible == true) {
      return (
        <Portal>
          <Modal
              visible={visible}
              onDismiss={() => changeVisibility()}
              contentContainerStyle={{
                  backgroundColor:'white',
                  padding:20,
                  width: 325,
                  alignSelf: "center"
              }}>

            <View style={{alignItems: "center"}}>
              
            <View style={{width: 300}}>
              <Text style={{fontSize: 16, paddingBottom: 10, textAlign: "center"}}>Suspending your subscription will remove it from your homescreen.</Text>
            </View>

            <View style={{width: 300}}>
              <Text style={{fontSize: 16, paddingBottom: 10, textAlign: "center"}}>If you renew your subscription at a later date, your payment history and followed titles will still be present.</Text>
            </View>

            <View style={{width: 300}}>
              <Text style={{fontSize: 16, fontWeight: 'bold', textAlign: "center"}}>NOTE: MyTV does not cancel subscriptions for you.</Text>
            </View>

            <View style={{flexDirection: "row"}}>
              <CustomButton text="Back" customStyle={{ width: 120, marginRight: 20}} onPress={() => changeVisibility()}/>
              <CustomButton text="Confirm" customStyle={{width: 120, marginLeft: 20 }} onPress={() => suspend()}/>
            </View>
            </View>
          </Modal>
        </Portal>
      );
    }
  }

  //
  // Notification Display
  //
  function DisplayNotification() {


    if(notificationData.length == 0) {
      return(
        <View style={{paddingTop: 30}}>
          <Text style={{textAlign: "center", paddingBottom: 40}}>No Notifications at this time!</Text>
        </View>
      );
    } else {
      

      var tempArray = []

      for(const property in notificationData) {
        tempArray.push(notificationData[property].title)
      }

      if(tempArray.length == 1) {
        return(
          <View style={{paddingBottom: 6}}>
            {tempArray.map(element => {
              return(
  
                <View style={{ alignSelf: "center", paddingTop: 7, marginLeft: 15, marginRight: 15, borderTopWidth: 1, borderTopColor: "#e3e3e3", width: "100%"}} key={element}>
                  <Text style={{textAlign: 'center', paddingBottom: 5}}><Text style={{fontWeight: "bold"}}>{element}</Text> has been removed!</Text>
                </View>
              )
            })}
            <View></View>
          </View>
          )
      }
      if(tempArray.length == 2) {
        return(
          <View style={{paddingBottom: 6}}>
            {tempArray.map(element => {
              return(
  
                <View style={{ alignSelf: "center", paddingTop: 7, marginLeft: 15, marginRight: 15, borderTopWidth: 1, borderTopColor: "#e3e3e3", width: "100%" }} key={element}>
                  <Text style={{textAlign: 'center', paddingBottom: 5}}><Text style={{fontWeight: "bold"}}>{element}</Text> has been removed!</Text>
                </View>
              )
            })}
            <View></View>
          </View>
          )
      }
      else {
        return(
          <View style={{paddingBottom: 6}}>
            {tempArray.slice(tempArray.length - 3, tempArray.length).map(element => {
              return(
  
                <View style={{ alignSelf: "center", paddingTop: 7, marginLeft: 15, marginRight: 15, borderBottomWidth: 1, borderBottomColor: "#e3e3e3", width: "100%" }} key={element}>
                  <Text style={{textAlign: 'center', paddingBottom: 9, paddingTop: 5}}><Text style={{fontWeight: "bold"}}>{element}</Text> has been removed!</Text>
                </View>
              )
            })}
            <View></View>
          </View>
          )
      }
    }
  }

  //
  // Payment tab
  //
  const FirstRoute = (props) => (
      <View style={{flex: 1, alignItems: "center", backgroundColor: "#f0f0f0"}}>
          <ScrollView   showsVerticalScrollIndicator={false} showsHorizontalScrollIndicator={false}>
          <View elevation={5} style={styles.top}>
            {image}

            <Button disabled mode="contained" onPress={() => {}} style={styles.button}>
              <Text style={styles.text1}>Payment of {paymentData.price} due on {paymentData.renewalDate}</Text>
            </Button>
          </View>

          <View elevation={5} style={styles.middle}>
            <Pressable>
              <Text style={styles.text2}>Recent Payments</Text>
            </Pressable>

            <DataTable>
              <DataTable.Header>
                <DataTable.Title>Date</DataTable.Title>
                <DataTable.Title numeric>Amount</DataTable.Title>
              </DataTable.Header>
                <PopulatePaymentData/>
              </DataTable>

              <Pressable onPress={() => navigation.navigate("Payment Screen", {service: route.params.service})} style={{ alignItems: "center", paddingTop: 14, paddingBottom: 14, borderTopWidth: 1, borderTopColor: "#e3e3e3"}}>
                <Text style={{ fontSize: 16, lineHeight: 21, letterSpacing: 0.25, color: "#55b0ca"}}>View Payments</Text>
              </Pressable>
          </View>


          <View style={styles.bottom}>
            <Text style={styles.text3}>Notifications</Text>
              <DisplayNotification/>
            <Pressable onPress={() => navigation.navigate("Notifications Screen", {services: route.params.services})} style={{ alignItems: "center", paddingBottom: 14, paddingTop: 9}}>
                <Text style={{ fontSize: 16, lineHeight: 21, letterSpacing: 0.25, color: "#55b0ca"}}>View Notifications</Text>
            </Pressable>
          </View>


          <DialogBox/>
          <View style={styles.suspendButton}>
            <CustomButton text="Suspend Subscription" onPress={() => changeVisibility()}/>
          </View>
        </ScrollView>
      </View>
  )

  //
  // Following tab
  //
  const SecondRoute = (props) => (
        <ScrollView style={{}}>
            <View style={styles.changeBanner}>
            <Pressable onPress={() => navigation.navigate('Changes Screen', {service: route.params.service})}>
              <Button disabled mode="contained" onPress={() => {}} style={styles.button2}>
                <Text style={styles.text1}>What's Changing on {route.params.service}?</Text>
              </Button>
            </Pressable>
            </View>
          <PopulateFollowingData/>
        </ScrollView>
  );

  //
  // Custom scene render to pass props properly
  //
  const renderScene = ({ route }) => {
    switch (route.key) {
      case 'first':
        return <FirstRoute/>;
      case 'second':
        return <SecondRoute/>;
      default:
        return null;
    }
  };

  const renderTabBar = props => (
      <TabBar
        {...props}
        indicatorStyle={{ backgroundColor: 'white' }}
        style={{ backgroundColor: 'black' }}
      />
  );
  
    return (
      <TabView  
          renderTabBar={renderTabBar}
          navigationState={{ index, routes }}
          renderScene={renderScene}
          onIndexChange={setIndex}
          initialLayout={{ width: layout.width }}
      />
    );
}

export default SST;