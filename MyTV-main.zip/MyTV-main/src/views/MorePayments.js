import React from 'react';
import { StyleSheet, Text, View, SafeAreaView, ScrollView, useWindowDimensions } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { DataTable } from "react-native-paper";
import { useState,useCallback } from 'react';
import { useFocusEffect } from '@react-navigation/native';
import { getAuth } from "firebase/auth";
import { getDatabase, ref, child, get, onValue, remove } from "firebase/database";
import { useLayoutEffect } from 'react';

//
// Screen to display all of the payments a user has made
//
function MorePayments({ navigation, route}) {
    
    // Hooks
    const [paymentData, setPaymentData] = useState([]);

    // Current user auth and database reference
    const auth = getAuth();
    let uid = auth.currentUser.uid;
    const dbRef = ref(getDatabase());

  //
  // Setup header options
  //
  useLayoutEffect(() => {
        navigation.setOptions({
            headerTitle: () => <Text style={{color: "black", fontWeight: "bold", fontSize: 25}}><Text style={{fontWeight: "normal", color: "white", fontSize: 25}}>my</Text>{route.params.service}</Text>,
            headerBackTitle: "",
            headerStyle: {backgroundColor: "#55b0ca"},
            headerTitleStyle: { fontSize: 24, color: "black" },
        })

    }, [navigation])

    //
    // Get the data required for the screen to render
    //
    useFocusEffect(
        useCallback(() => {
            get(child(dbRef, `users/${uid}/services/${route.params.service}/subscription/payments`)).then((snapshot) => {
                if (snapshot.exists()) {
                    let data = snapshot.val();
                    setPaymentData(data);
                } else {
                    console.log("No data available");
                }
            }).catch((error) => {
               console.error(error);
            });
        }, [])
    );
    
    //
    // populate Data
    //
    let populateData =
    populateData = paymentData.map(val => {
        return (
            <DataTable.Row key={val.date}>
              <DataTable.Cell>{val.date}</DataTable.Cell>
              <DataTable.Cell numeric>{val.price}</DataTable.Cell>
            </DataTable.Row>
        );
    })

    //
    // total payment
    //
    let totalPayment = 0;
    paymentData.map(val => {
        let convert = parseFloat(val.price.replace('$', ''));
        totalPayment += convert;
    });

    //
    // Screen render
    //
    return (
        <ScrollView>
            <View style={{ alignItems: "center", paddingTop: 10, paddingBottom: 5}}>
                <Text style={{fontSize: 25, fontWeight: "bold"}}>Recent Payments</Text>
            </View>
            <DataTable>
                <DataTable.Header>
                    <DataTable.Title>Date</DataTable.Title>
                    <DataTable.Title numeric>Amount</DataTable.Title>
                </DataTable.Header>
                {populateData}
            </DataTable>
            <View style={{flexDirection: 'row', paddingTop: '3%'}}>
                <Text style={{fontWeight: 'bold', paddingLeft: '4%'}}>Total:</Text>
                <Text style={{paddingLeft: '71%'}}>${totalPayment}</Text>
            </View>
        </ScrollView>
    );
}

export default MorePayments;