import { StatusBar } from 'expo-status-bar';
import React, { useState } from 'react';
import { StyleSheet, Text, View, SafeAreaView } from 'react-native';
import { db, firebase } from '../../firebase-config'; 
import { getDatabase, push, ref, set, update, get, child } from "firebase/database";
import { getAuth, createUserWithEmailAndPassword, signOut, signInWithEmailAndPassword} from "firebase/auth";
import CustomButton from '../components/button.js';
import { Dropdown } from 'react-native-element-dropdown';
import MaskInput, { Masks, createNumberMask } from 'react-native-mask-input';
import { useRoute } from '@react-navigation/native';
import { render } from 'react-dom';
import { DefaultTheme, Provider as PaperProvider } from 'react-native-paper';
import { DatePickerInput } from 'react-native-paper-dates';
import { SafeAreaProvider } from "react-native-safe-area-context";
import styles from '../styling/AddServiceScreen.style.js';
// Dropdown: https://www.npmjs.com/package/react-native-element-dropdown
// Date picker: https://web-ridge.github.io/react-native-paper-dates/docs/intro

  const data = [
    { label: 'Netflix', value: 'Netflix' },
    { label: 'Disney+', value: 'Disney+' },
    { label: 'HBO Max', value: 'HBO' },
    { label: 'Hulu', value: 'Hulu' },
  ];

  const netflixPrices = [
    { label: '$6.99 (Basic + Ads)', value: '$6.99' },
    { label: '$9.99 (Basic)', value: '$9.99' },
    { label: '$15.49 (Standard)', value: '$15.49' },
    { label: '$19.99 (Premium)', value: '$19.99' },
  ];

  const disneyPrices = [
    { label: '$7.99 (Basic)', value: '$7.99' },
    { label: '$10.99 (Premium)', value: '$10.99' },
    { label: '$9.99 (Duo Basic)', value: '$9.99' },
    { label: '$12.99 (Trio Basic)', value: '$12.99' },
    { label: '$19.99 (Trio Premium)', value: '$19.99' },
  ];

  const hboPrices = [
    { label: '$9.99 (Monthly + Ads)', value: '$9.99' },
    { label: '$15.99 (Monthly)', value: '$15.99' },
    { label: '$99.99 (Yearly + Ads)', value: '$99.99' },
    { label: '$149.99 (Yearly)', value: '$149.99' },
  ]

  const huluPrices = [
    { label: '$7.99 (Ads)', value: '$7.99' },
    { label: '$12.99 (Bundle Trio Basic)', value: '$12.99' },
    { label: '$14.99 (No Ads)', value: '$14.99' },
    { label: '$19.99 (Bundle Trio Premium)', value: '$19.99' },
    { label: '$69.99 (Live TV)', value: '$69.99' },
    { label: '$82.99 (No Ads + Live TV)', value: '$82.99' },
  ];

  const theme = {
    ...DefaultTheme,
    colors: {
      ...DefaultTheme.colors,
      primary: '#99cfdf',
    },
  };

 function AddServiceScreen({navigation}) {
    const [value, setValue] = useState(null);
    const [isFocus, setIsFocus] = useState(false);

    const [value2, setValue2] = React.useState('');
    const [isFocus2, setIsFocus2] = useState(false);

    const [inputDate, setInputDate] = React.useState('');

    const renderLabel = () => {
    if (value || isFocus) {
        return (
        <Text style={[styles.label, isFocus && { color: 'blue' }]}>
            Streaming Services
        </Text>
        );
    }
    return null;
    };

    const renderLabel2 = () => {
        if (value2 || isFocus2) {
          return (
            <Text style={[styles.label, isFocus2 && { color: 'blue' }]}>
              Price
            </Text>
          );
        }
        return null;
      };

    //
    // Function that adds the service to the user's
    // service array in firebase and routes user to homepage
    //
    function addService(navigation) {

        const auth = getAuth();
        const dbRef = ref(getDatabase());
        const uid = auth.currentUser.uid;

        var purchaseDate = inputDate.toLocaleDateString()

        var testDate = new Date(purchaseDate);
        testDate.setMonth(testDate.getMonth() + 1)

        var renewalDate = (testDate.toLocaleDateString());

        get(child(dbRef, `users/${uid}/services/${value}`)).then((snapshot) => {
            if (snapshot.exists()) {

                // Existing service renewal
                update(child(dbRef, `users/${uid}/services/${value}/subscription`), {
                    "purchaseDate": purchaseDate,
                    "renewalDate": renewalDate,
                    "status": "active",
                    "price": value2,
                }).then(() => {
                    get(ref(db, `users/${uid}/services/${value}/subscription/payments`)).then((snapshot) => {
                    
                        let key = snapshot.size;
    
                        set(ref(db, `users/${uid}/services/${value}/subscription/payments/${key}`), {
                            "date": purchaseDate,
                            "price": value2
                        }).then(() => {
                            navigation.navigate("mySubscriptions");
                        })
                    })  
                })

            } else {
                // New Service Add
                update(child(dbRef, `users/${uid}/services/${value}/subscription`), {
                    "purchaseDate": purchaseDate,
                    "renewalDate": renewalDate,
                    "status": "active",
                    "price": value2,
                    "payments": [{"price": value2, "date": purchaseDate}]
                }).then(() => {
                    navigation.navigate("mySubscriptions");
                })
            }
            }).catch((error) => {
              console.error(error);
        });
    };

    function PriceDropdownBox() {
        if (value !== undefined)
        {
            if (value == 'Netflix')
            {
                return(
                    <View style={styles.container}>
                        {renderLabel2()}
                        <Dropdown
                        style={[styles.dropdown, isFocus2 && { borderColor: 'blue' }]}
                        placeholderStyle={styles.placeholderStyle}
                        selectedTextStyle={styles.selectedTextStyle}
                        iconStyle={styles.iconStyle}
                        data={netflixPrices}
                        maxHeight={300}
                        labelField="label"
                        valueField="value"
                        placeholder={!isFocus2 ? 'Select Price' : '...'}
                        value={value2}
                        // onFocus={() => setIsFocus2(true)}
                        onBlur={() => setIsFocus2(false)}
                        onChange={item => {
                            setValue2(item.value);
                            setIsFocus2(false);
                        }}/>
                    </View>
                );
            }
            else if (value == 'Disney+')
            {
                return(
                    <View style={styles.container}>
                        {renderLabel2()}
                        <Dropdown
                        style={[styles.dropdown, isFocus2 && { borderColor: 'blue' }]}
                        placeholderStyle={styles.placeholderStyle}
                        selectedTextStyle={styles.selectedTextStyle}
                        iconStyle={styles.iconStyle}
                        data={disneyPrices}
                        maxHeight={300}
                        labelField="label"
                        valueField="value"
                        placeholder={!isFocus2 ? 'Select Price' : '...'}
                        value={value2}
                        // onFocus={() => setIsFocus2(true)}
                        onBlur={() => setIsFocus2(false)}
                        onChange={item => {
                            setValue2(item.value);
                            setIsFocus2(false);
                        }}/>
                    </View>
                );
            }
            else if (value == 'HBO')
            {
                return(
                    <View style={styles.container}>
                        {renderLabel2()}
                        <Dropdown
                        style={[styles.dropdown, isFocus2 && { borderColor: 'blue' }]}
                        placeholderStyle={styles.placeholderStyle}
                        selectedTextStyle={styles.selectedTextStyle}
                        iconStyle={styles.iconStyle}
                        data={hboPrices}
                        maxHeight={300}
                        labelField="label"
                        valueField="value"
                        placeholder={!isFocus2 ? 'Select Price' : '...'}
                        value={value2}
                        // onFocus={() => setIsFocus2(true)}
                        onBlur={() => setIsFocus2(false)}
                        onChange={item => {
                            setValue2(item.value);
                            setIsFocus2(false);
                        }}/>
                    </View>
                );
            }
            else if (value == 'Hulu')
            {
                return(
                    <View style={styles.container}>
                        {renderLabel2()}
                        <Dropdown
                        style={[styles.dropdown, isFocus2 && { borderColor: 'blue' }]}
                        placeholderStyle={styles.placeholderStyle}
                        selectedTextStyle={styles.selectedTextStyle}
                        iconStyle={styles.iconStyle}
                        data={huluPrices}
                        maxHeight={300}
                        labelField="label"
                        valueField="value"
                        placeholder={!isFocus2 ? 'Select Price' : '...'}
                        value={value2}
                        // onFocus={() => setIsFocus2(true)}
                        onBlur={() => setIsFocus2(false)}
                        onChange={item => {
                            setValue2(item.value);
                            setIsFocus2(false);
                        }}/>
                    </View>
                );
            }
        }
    }

    return (
    <SafeAreaView style={styles.container1}>
        <Text style={styles.text}>Add Streaming Service</Text>

        <View style={styles.container}>
            {renderLabel()}
            <Dropdown
            style={[styles.dropdown, isFocus && { borderColor: 'blue' }]}
            placeholderStyle={styles.placeholderStyle}
            selectedTextStyle={styles.selectedTextStyle}
            inputSearchStyle={styles.inputSearchStyle}
            iconStyle={styles.iconStyle}
            data={data}
            search
            maxHeight={300}
            labelField="label"
            valueField="value"
            placeholder={!isFocus ? 'Select Service' : '...'}
            searchPlaceholder="Search..."
            value={value}
            onFocus={() => setIsFocus(true)}
            onBlur={() => setIsFocus(false)}
            onChange={item => {
                setValue(item.value);
                setIsFocus(false);
            }}/>
        </View>
        <PriceDropdownBox/>

        <PaperProvider theme={theme}>
            <>
            <View style={styles.date}>
                <DatePickerInput
                locale="en"
                label="Purchased:"
                value={inputDate}
                onChange={(d) => setInputDate(d)}
                editable={false}
                inputMode="start"
                style={{backgroundColor: '#99cfdf'}}
                />
            </View>
            </>
            
            <View style={styles.middle2}>
                <CustomButton onPress={() => addService(navigation)} text="Add Service"/>
            </View>
        </PaperProvider>
    </SafeAreaView>
    );
}

export default AddServiceScreen;