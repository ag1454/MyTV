import React, {useState, useCallback } from 'react';
import { StyleSheet, Text, View, Image, Pressable, ScrollView, useWindowDimensions, Dimensions } from 'react-native';
import { Card, IconButton, Button } from "react-native-paper";
import styles from '../styling/HomeScreen.style.js';
import { useFocusEffect } from '@react-navigation/native';
import { getAuth } from "firebase/auth";
import { getDatabase, ref, child, get, remove, update } from "firebase/database";
import { useLayoutEffect } from 'react';
import { TabView, TabBar } from 'react-native-tab-view';
import { PieChart, BarChart } from "react-native-chart-kit";

var services = []

function HomeScreen({route, navigation}) {
    //
    // Object that matches service to the proper image
    //
    const userServiceImage = {
        'Disney+': require("../../assets/disneylogo2.jpg"),
        "HBO": require("../../assets/HBO.png"),
        "Hulu": require("../../assets/hulu.jpg"),
        "Netflix": require("../../assets/Netflix.png"),
    }


    // Hooks
    const [userData, setUserData] = useState([])
    const [allData, setAllData] = useState([])
    const [index, setIndex] = useState(0);
    const [routes, setRoutes] = useState([
        { key: 'first', title: "Dashboard" },
        { key: 'second', title: "Summary"}
    ]); 

    const layout = useWindowDimensions();

    // Current user auth and database reference
    const auth = getAuth();
    let uid = auth.currentUser.uid;
    const dbRef = ref(getDatabase());

    //
    // Setup header options
    //
    useLayoutEffect(() => {
        navigation.setOptions({
            headerTitle: () => <Text style={{color: "black", fontWeight: "bold", fontSize: 25}}><Text style={{fontWeight: "normal", color: "white", fontSize: 25}}>my</Text>Subscriptions</Text>,
            headerBackVisible: false,
            headerStyle: {backgroundColor: "#55b0ca"},
            headerTitleStyle: { fontSize: 24, color: "black" },
            gestureEnabled: false,
            headerRight: () => (
              <IconButton
                icon="account"
                iconColor="black"
                size={30}
                style={{width: 30, height: 30}}
                onPress={() => navigation.navigate("Profile Screen")}
              />
            ),
            headerLeft: () => (
              <IconButton
                icon="flag-variant"
                iconColor="black"
                size={30}
                style={{width: 30, height: 30}}
                onPress={() => navigation.navigate("Notifications Screen", {services: services})}
              />
            ),
        })

    }, [navigation])

    //
    // Get the data required for the screen to render
    //
    useFocusEffect(
        useCallback(() => {

            setUserData([]);
            services = [];

            get(child(dbRef, `users/${uid}/services`)).then((snapshot) => {
                if (snapshot.exists()) {
                    let data = snapshot.val();
                    setAllData(data);

                        for (const key in data) {
                            // console.log(data[key].subscription.status);
                            if(data[key].subscription.status == "active") {
                                setUserData(userData => [...userData, key])
                                services.push(key);
                            } 
                        }
                } else {
                    console.log("No data available");
                }
                }).catch((error) => {
                console.error(error);
            });

        }, [])
    );
    
    //
    // Function to get info from firebase and route user to service page
    //
    function grabServiceInfo(navigation, service) {

        navigation.navigate("SST", {service: service, services: services})
    }

    //
    // Function to render the display of the screen
    //
    function Display(props) {

        if(userData.length == 0) {
            return (
                <View style={styles.container}>
                    <View style={styles.initialView} contentContainerStyle={styles.contentContainer}>
                        <Text style={{ alignSelf: "center", fontSize: 39 }}>Welcome to MyTV! </Text>
                        <Text style={{ alignSelf: "center", fontSize: 17, paddingTop: 5 }}>Add Services using the button below</Text>
                        
                        <View style={{paddingTop: 20}}>
                        <IconButton
                            icon="plus-circle"
                            color="black"
                            size={40}
                            onPress={() => props.navigation.navigate("Add Service Screen")}
                        />
                        </View>

                    </View>
                </View>
            );
        } 

        else if(userData.length > 0 && userData.length < 4) {
            return(
                <View>
                    {userData.map(element => {
                        return(
                            <View key={element} style={{alignItems: "center", paddingBottom: 5}}>
                                <Pressable onPress={() => grabServiceInfo(props.navigation, element)} style={{ width: "95%"}}>
                                        <Card mode="elevated" style={styles[element]}>
                                            <Card.Content style={{alignItems: "center"}}>
                                                <Image source={userServiceImage[element]} style={{width: 200,height: 80}}></Image>
                                            </Card.Content>
                                        </Card>
                                </Pressable>
                            </View>
                        );
                    })}
                    <View style={{ alignItems: "center", paddingTop: 20}}>
                    <IconButton
                        icon="plus-circle"
                        color="black"
                        size={40}
                        onPress={() => props.navigation.navigate("Add Service Screen")}
                    />
                    </View>
                </View>
            )
        }

        else {
            return(
                userData.map(element => {
                    return(
                        <View key={element} style={{alignItems: "center", paddingBottom: 5}}>
                            <Pressable onPress={() => grabServiceInfo(props.navigation, element)} style={{ width: "95%"}}>
                                    <Card mode="elevated" style={styles[element]}>
                                        <Card.Content style={{alignItems: "center"}}>
                                            <Image source={userServiceImage[element]} style={{width: 200,height: 80}}></Image>
                                        </Card.Content>
                                    </Card>
                            </Pressable>
                        </View>
                    );
                })
            )
        }
    }

    //
    // Chart Display Code
    //
    var data = []
    var data1 = []
    var data2 = []

    //
    // Calculate Total spent on a service
    //
    function calculateTotal(service) {
        var netflixTotal = 0;
        var huluTotal = 0;
        var hboTotal = 0;
        var disneyTotal = 0;
    
        if(service == "Netflix") {
            var netflixLength = allData.Netflix.subscription.payments.length
            var netflixPrice = parseFloat(allData.Netflix.subscription.price.slice(1))
            netflixTotal = netflixLength * netflixPrice
            return netflixTotal
        }
    
        if(service == "Hulu") {
            var huluLength = allData.Hulu.subscription.payments.length
            var huluPrice = parseFloat(allData.Hulu.subscription.price.slice(1))
            huluTotal = huluLength * huluPrice
            return huluTotal
        }
    
        if(service == "HBO") {
            var hboLength = allData.HBO.subscription.payments.length
            var hboPrice = parseFloat(allData.HBO.subscription.price.slice(1))
            hboTotal = hboLength * hboPrice
            return hboTotal
        }
    
        if(service == "Disney+") {
            var disneyLength = allData['Disney+'].subscription.payments.length
            var disneyPrice = parseFloat(allData['Disney+'].subscription.price.slice(1))
            disneyTotal = disneyLength * disneyPrice
            return disneyTotal
        }
    }

    //
    // Calculate price per month
    //
    function calculatePrice(service) {
    
        if(service == "Netflix") {
            var netflixPrice = parseFloat(allData.Netflix.subscription.price.slice(1))
            return netflixPrice
        }
    
        if(service == "Hulu") {
            var huluPrice = parseFloat(allData.Hulu.subscription.price.slice(1))
            return huluPrice
        }
    
        if(service == "HBO") {
            var hboPrice = parseFloat(allData.HBO.subscription.price.slice(1))
            return hboPrice
        }
    
        if(service == "Disney+") {
            var disneyPrice = parseFloat(allData['Disney+'].subscription.price.slice(1))
            return disneyPrice
        }
    }


    //
    // Calculate color based on service
    //
    function calculateFollowing(service) {
    
        if(service == "Netflix") {
            if(allData.Netflix.following){
                var netflixFollowing = Object.keys(allData.Netflix.following).length
                return netflixFollowing
            } else {
                return 0
            }
        }
    
        if(service == "Hulu") {
            if(allData.Hulu.following){
                var huluFollowing = Object.keys(allData.Hulu.following).length
                return huluFollowing
            } else {
                return 0
            }
        }
    
        if(service == "HBO") {
            if(allData.HBO.following){
                var hboFollowing = Object.keys(allData.HBO.following).length
                return hboFollowing
            } else {
                return 0
            }
        }
    
        if(service == "Disney+") {
            if(allData['Disney+'].following) {
                var disneyFollowing = Object.keys(allData['Disney+'].following).length
                return disneyFollowing
            } else {
                return 0
            }
        }
    }

    //
    // Calculate how many titles are being followed on a service
    //
    function calculateColor(service) {
            
        if(service == "Netflix") {
            return 'red'
        }
    
        if(service == "Hulu") {
            return '#4bd654'
        }
    
        if(service == "HBO") {
            return "#651680"
        }
    
        if(service == "Disney+") {
            return "#0E47A1"
        }
    }

    //
    // Display the proper chart based on services added
    //
    if(userData.length == 1) {
        data = [
            {
                name: userData[0], total: calculateTotal(userData[0]), color: calculateColor(userData[0]),
                legendFontColor: "black", legendFontSize: 15
            }
        ];

        data1 = [
            {
                name: userData[0], total: calculatePrice(userData[0]), color: calculateColor(userData[0]),
                legendFontColor: "black", legendFontSize: 15
            }
        ];

        data2 = [
            {
                name: userData[0], total: calculateFollowing(userData[0]), color: calculateColor(userData[0]),
                legendFontColor: "black", legendFontSize: 15
            }
        ];
    }
    if(userData.length == 2) {
        data = [
            {
                name: userData[0], total: calculateTotal(userData[0]), color: calculateColor(userData[0]),
                legendFontColor: "black", legendFontSize: 15
            },
            {
                name: userData[1], total: calculateTotal(userData[1]), color: calculateColor(userData[0]),
                legendFontColor: "black", legendFontSize: 15
            },
        ];

        data1 = [
            {
                name: userData[0], total: calculatePrice(userData[0]), color: calculateColor(userData[0]),
                legendFontColor: "black", legendFontSize: 15
            },
            {
                name: userData[1], total: calculatePrice(userData[1]), color: calculateColor(userData[0]),
                legendFontColor: "black", legendFontSize: 15
            },
        ];

        data2 = [
            {
                name: userData[0], total: calculateFollowing(userData[0]), color: calculateColor(userData[0]),
                legendFontColor: "black", legendFontSize: 15
            },
            {
                name: userData[1], total: calculateFollowing(userData[1]), color: calculateColor(userData[0]),
                legendFontColor: "black", legendFontSize: 15
            },
        ];
    }
    if(userData.length == 3) {
        data = [
            {
                name: userData[0], total: calculateTotal(userData[0]), color: calculateColor(userData[0]),
                legendFontColor: "black", legendFontSize: 15
            },
            {
                name: userData[1], total: calculateTotal(userData[1]), color: calculateColor(userData[1]),
                legendFontColor: "black", legendFontSize: 15
            },
            {
                name: userData[2], total: calculateTotal(userData[2]), color: calculateColor(userData[2]),
                legendFontColor: "black", legendFontSize: 15
            }
        ];

        data1 = [
            {
                name: userData[0], total: calculatePrice(userData[0]), color: calculateColor(userData[0]),
                legendFontColor: "black", legendFontSize: 15
            },
            {
                name: userData[1], total: calculatePrice(userData[1]), color: calculateColor(userData[1]),
                legendFontColor: "black", legendFontSize: 15
            },
            {
                name: userData[2], total: calculatePrice(userData[2]), color: calculateColor(userData[2]),
                legendFontColor: "black", legendFontSize: 15
            }
        ];

        data2 = [
            {
                name: userData[0], total: calculateFollowing(userData[0]), color: calculateColor(userData[0]),
                legendFontColor: "black", legendFontSize: 15
            },
            {
                name: userData[1], total: calculateFollowing(userData[1]), color: calculateColor(userData[1]),
                legendFontColor: "black", legendFontSize: 15
            },
            {
                name: userData[2], total: calculateFollowing(userData[2]), color: calculateColor(userData[2]),
                legendFontColor: "black", legendFontSize: 15
            }
        ];
    }
    if(userData.length == 4) {
        data = [
            {
                name: userData[0], total: calculateTotal(userData[0]), color: calculateColor(userData[0]),
                legendFontColor: "black", legendFontSize: 15
            },
            {
                name: userData[1], total: calculateTotal(userData[1]), color: calculateColor(userData[1]),
                legendFontColor: "black", legendFontSize: 15
            },
            {
                name: userData[2],total: calculateTotal(userData[2]), color: calculateColor(userData[2]),
                legendFontColor: "black", legendFontSize: 15
            },
            {
                name: userData[3], total: calculateTotal(userData[3]), color: calculateColor(userData[3]),
                legendFontColor: "black", legendFontSize: 15
            }
        ];

        data1 = [
            {
                name: userData[0], total: calculatePrice(userData[0]), color: calculateColor(userData[0]),
                legendFontColor: "black", legendFontSize: 15
            },
            {
                name: userData[1], total: calculatePrice(userData[1]), color: calculateColor(userData[1]),
                legendFontColor: "black", legendFontSize: 15
            },
            {
                name: userData[2],total: calculatePrice(userData[2]), color: calculateColor(userData[2]),
                legendFontColor: "black", legendFontSize: 15
            },
            {
                name: userData[3], total: calculatePrice(userData[3]), color: calculateColor(userData[3]),
                legendFontColor: "black", legendFontSize: 15
            }
        ];

        data2 = [
            {
                name: userData[0], total: calculateFollowing(userData[0]), color: calculateColor(userData[0]),
                legendFontColor: "black", legendFontSize: 15
            },
            {
                name: userData[1], total: calculateFollowing(userData[1]), color: calculateColor(userData[1]),
                legendFontColor: "black", legendFontSize: 15
            },
            {
                name: userData[2],total: calculateFollowing(userData[2]), color: calculateColor(userData[2]),
                legendFontColor: "black", legendFontSize: 15
            },
            {
                name: userData[3], total: calculateFollowing(userData[3]), color: calculateColor(userData[3]),
                legendFontColor: "black", legendFontSize: 15
            }
        ];
    }

    //
    // Chart configuration
    //
    const chartConfig = {
        backgroundGradientFrom: "#1E2923",
        backgroundGradientFromOpacity: 0,
        backgroundGradientTo: "#08130D",
        backgroundGradientToOpacity: 0.5,
        color: (opacity = 1) => `rgba(26, 255, 146, ${opacity})`,
        strokeWidth: 2, // optional, default 3
        barPercentage: 0.5,
        useShadowColorFromDataset: false // optional
    };

    //
    // Chart display component
    //
    function ChartDisplay() {

        var total = 0

        data.forEach(element => {
            total = total + element.total
        });

        var perMonth = 0
        data1.forEach(element => {
            perMonth = perMonth + element.total
        });

        if(userData.length == 0) {
            return (
                <View style={styles.container}>
                    <View style={styles.initialView} contentContainerStyle={styles.contentContainer}>
                        <Text style={{ alignSelf: "center", fontSize: 39 }}>Welcome to MyTV! </Text>
                        <Text style={{ alignSelf: "center", fontSize: 17, paddingTop: 5 }}>Add Services using the button below</Text>
                        
                        <View style={{paddingTop: 20}}>
                        <IconButton
                            icon="plus-circle"
                            color="black"
                            size={40}
                            onPress={() => props.navigation.navigate("Add Service Screen")}
                        />
                        </View>

                    </View>
                </View>
            );
        }
        else {
            return(
                <View style={{paddingBottom: 30}}>
                    <View>
                        <Text style={{textAlign: "center", fontWeight: "bold", fontSize: 18}}>Total Spent Breakdown: ${parseFloat(total).toFixed(2)}</Text>
                        <PieChart
                        data={data}
                        width={Dimensions.get("window").width}
                        height={220}
                        chartConfig={chartConfig}
                        accessor={"total"}
                        backgroundColor={"transparent"}
                        paddingLeft={"15"}
                        center={[10, 0]}
                        absolute
                        />
                    </View>

                    <View>
                        <Text style={{textAlign: "center", fontWeight: "bold", fontSize: 18}}>Monthly Breakdown: ${parseFloat(perMonth).toFixed(2)}</Text>
                        <PieChart
                        data={data1}
                        width={Dimensions.get("window").width}
                        height={220}
                        chartConfig={chartConfig}
                        accessor={"total"}
                        backgroundColor={"transparent"}
                        paddingLeft={"15"}
                        center={[10, 0]}
                        // absolute
                        />
                    </View>

                    <View>
                        <Text style={{textAlign: "center", fontWeight: "bold", fontSize: 18}}>Followed Titles Per Service:</Text>
                        <PieChart
                        data={data2}
                        width={Dimensions.get("window").width}
                        height={220}
                        chartConfig={chartConfig}
                        accessor={"total"}
                        backgroundColor={"transparent"}
                        paddingLeft={"15"}
                        center={[10, 0]}
                        absolute
                        />
                    </View>
                </View>
            );
        }
    }

    //
    // Base page returns
    //
    const FirstRoute = (props) => (
        <ScrollView style={{paddingTop: 7, backgroundColor: "white"}}>
            <Display route={route} navigation={navigation}/>
        </ScrollView>
    );

    const SecondRoute = (props) => (
        <ScrollView style={{paddingTop: 10, backgroundColor: "white"}}>
            <ChartDisplay route={route} navigation={navigation}/>
        </ScrollView>
    );

    //
    // Custom scene render to pass props properly
    //
    const renderScene = ({ route }) => {
        switch (route.key) {
        case 'first':
            return <FirstRoute/>;
        case 'second':
            return <SecondRoute/>;
        default:
            return null;
        }
    };

    const renderTabBar = props => (
        <TabBar
            {...props}
            indicatorStyle={{ backgroundColor: 'white' }}
            style={{ backgroundColor: 'black' }}
        />
    );
    
    return (
        <TabView  
            renderTabBar={renderTabBar}
            navigationState={{ index, routes }}
            renderScene={renderScene}
            onIndexChange={setIndex}
            initialLayout={{ width: layout.width }}
        />
    );
}

export default HomeScreen;