import React from 'react';
import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View, SafeAreaView, Button } from 'react-native';


export default function AboutScreen(){
    return (
        <View style={styles.container}>
            
            {/* Logo */}
            <View style={{paddingTop: 0}}>
            <Text style={styles.myTV}>
            <Text style={{ fontWeight: "normal", color: "white" }}>my</Text>TV
            </Text>
            </View>
            
            {/* Title */}
            <View style={{alignItems: "center"}}>
            <Text style={styles.aboutUs}>About myTV</Text>
            <Text style={styles.aboutText}>MyTV is a subscription management app that allows users to 
                automate manual processes such as recurring
                billing, pricing and payment. 
                 </Text>
            </View>

            {/* Developer Names */}
            <View style={{alignItems: "center", paddingTop: 140}}>
            <Text style={{fontWeight: "bold", fontSize: 19}}> Developers:
            </Text>
            <Text style={styles.devNames}> Garrett Nissley, Tyler Regitz,
            Abigail Garrido, Nathan Bowman, Christian Reames</Text>
            </View>

        
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: "center",
        backgroundColor: "#55b0ca",
    
    }, 

    myTV: { 
        marginTop: 50,
        fontWeight: "bold",
        textAlign: "top",
        textAlignVertical: "top",
        fontSize: 100,
        color: "black",
        marginBottom: 0
    
    },

    aboutUs: {
        paddingTop: 80,
        paddingBottom: 0,
        alignItems: "center",
        fontWeight: "bold",
        fontSize: 40,
    },
    
    aboutText: {
        marginBottom: 0,
        paddingLeft: 30,
        paddingRight: 30,
        alignItems: "center",
        textAlign: "center",
        fontSize: 19,
        
    },
    
    devNames: {
    
        textAlign: "center",
        textAlignVertical: "center",
        paddingLeft: 30,
        paddingRight: 30,
        paddingBottom: 120,
        alignItems: "center",
        fontSize: 18,
    }

});