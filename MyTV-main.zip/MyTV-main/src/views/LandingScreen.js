import { StatusBar } from 'expo-status-bar';
import React from 'react';
import { Text, View, SafeAreaView } from 'react-native';
import CustomButton from '../components/button.js';
import styles from '../styling/LandingScreen.style.js';
import { moviesLeaving } from '../functions/moviesLeaving.js'
import { seriesLeaving } from '../functions/seriesLeaving.js'

function LandingScreen({ navigation }) {
    return (
    <SafeAreaView style={styles.container}>
      
        <View style={styles.top}>
          <Text style={styles.myTV}>
            <Text style={{ fontWeight: "normal", color: "white" }}>my</Text>TV
          </Text>
        </View>

        <View style={styles.middle}>

            <View style={{paddingTop: 20}}>
              <CustomButton text="Login" onPress={() => navigation.navigate('Login Screen')}/>
            </View>

            <View style={{paddingTop: 10}}>
              <CustomButton text="Create Account" onPress={() => navigation.navigate('Create Account Screen 1')}/>
            </View>
{/* 
            <View style={{paddingTop: 10}}>
              <CustomButton text="Refresh DB" onPress={() => moviesLeaving()}/>
            </View>

            <View style={{paddingTop: 10}}>
              <CustomButton text="Refresh DB" onPress={() => seriesLeaving()}/>
            </View> */}


          <StatusBar style="auto" />
        </View>
    </SafeAreaView>
    );
}

export default LandingScreen;