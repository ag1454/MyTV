import React from 'react';
import { Button  } from 'react-native-paper';
import { StyleSheet } from 'react-native';

const CustomButton = ({text, onPress, customStyle}) => {
    return (
        <Button mode="outlined" style={[styles.button, customStyle]} onPress={onPress} labelStyle={[styles.buttonText]}>
            {text}
        </Button>
    );
};

export default CustomButton;

const styles = StyleSheet.create({
    button: {
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: 20,
        borderRadius: 4,
        borderColor: "#99cfdf",
        elevation: 3,
        backgroundColor: "#99cfdf",
        borderRadius: 41,
        height: 50,
        width: 230,
    },

    buttonText: {
        color: "white",
        fontSize: 16,
    }

});