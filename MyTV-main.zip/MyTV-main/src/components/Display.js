import React, { useState, useEffect } from 'react';
import { StyleSheet, Text, View, SafeAreaView, ScrollView, Image, Pressable } from 'react-native';
import { Searchbar, Button, Card, Title, Paragraph, Portal, Modal } from 'react-native-paper';

function Display(props) {

    if (!props.data) return null;

    if (props.data.length == 1) {
            return(
                <View style={{alignItems: "center", flexDirection: "row"}}>

                <Pressable style={{width: "50%"}} onPress={() => [props.setDialogObject(props.data[0]), props.changeVisibility()]}>
                    <Image style={{ height: 250, margin: 10}} source={{uri: props.data[0].posterURLs.original}}></Image>
                </Pressable>

                </View>
            )

    } else if (props.data.length == 2) {
        return(
            <View style={{alignItems: "center", flexDirection: "row"}}>

            <Pressable style={{width: "50%"}} onPress={() => [props.setDialogObject(props.data[0]), props.changeVisibility()]}>
                <Image style={{ height: 250, margin: 10}} source={{uri: props.data[0].posterURLs.original}}></Image>
            </Pressable>

            <Pressable style={{width: "50%"}} onPress={() => [props.setDialogObject(props.data[1]), props.changeVisibility()]}>
                <Image style={{ height: 250, margin: 10}} source={{uri: props.data[1].posterURLs.original}}></Image>
            </Pressable>

            </View>
        )

    } else if (props.data.length == 3) {
        return (
            <View>
                <View style={{alignItems: "center", flexDirection: "row"}}>

                <Pressable style={{width: "50%"}} onPress={() => [props.setDialogObject(props.data[0]), props.changeVisibility()]}>
                    <Image style={{ height: 250, margin: 10}} source={{uri: props.data[0].posterURLs.original}}></Image>
                </Pressable>

                <Pressable style={{width: "50%"}} onPress={() => [props.setDialogObject(props.data[1]), props.changeVisibility()]}>
                    <Image style={{ height: 250, margin: 10}} source={{uri: props.data[1].posterURLs.original}}></Image>
                </Pressable>

                </View>

                <View style={{alignItems: "center", flexDirection: "row"}}>

                <Pressable style={{width: "50%"}} onPress={() => [props.setDialogObject(props.data[2]), props.changeVisibility()]}>
                    <Image style={{ height: 250, margin: 10}} source={{uri: props.data[2].posterURLs.original}}></Image>
                </Pressable>

                </View>
            </View>
        )
        
    } else if (props.data.length == 4) {
        return (
            <View>

                <View style={{alignItems: "center", flexDirection: "row"}}>

                <Pressable style={{width: "50%"}} onPress={() => [props.setDialogObject(props.data[0]), props.changeVisibility()]}>
                    <Image style={{ height: 250, margin: 10}} source={{uri: props.data[0].posterURLs.original}}></Image>
                </Pressable>

                <Pressable style={{width: "50%"}} onPress={() => [props.setDialogObject(props.data[1]), props.changeVisibility()]}>
                    <Image style={{ height: 250, margin: 10}} source={{uri: props.data[1].posterURLs.original}}></Image>
                </Pressable>

                </View>

                <View style={{alignItems: "center", flexDirection: "row"}}>

                <Pressable style={{width: "50%"}} onPress={() => [props.setDialogObject(props.data[2]), props.changeVisibility()]}>
                    <Image style={{ height: 250, margin: 10}} source={{uri: props.data[2].posterURLs.original}}></Image>
                </Pressable>

                <Pressable style={{width: "50%"}} onPress={() => [props.setDialogObject(props.data[3]), props.changeVisibility()]}>
                    <Image style={{ height: 250, margin: 10}} source={{uri: props.data[3].posterURLs.original}}></Image>
                </Pressable>

                </View>

            </View>
        )
        
    } else if (props.data.length == 5) {
        return(
            <View>
                    
                    <View style={{alignItems: "center", flexDirection: "row"}}>

                    <Pressable style={{width: "50%"}} onPress={() => [props.setDialogObject(props.data[0]), props.changeVisibility()]}>
                        <Image style={{ height: 250, margin: 10}} source={{uri: props.data[0].posterURLs.original}}></Image>
                    </Pressable>

                    <Pressable style={{width: "50%"}} onPress={() => [props.setDialogObject(props.data[1]), props.changeVisibility()]}>
                        <Image style={{ height: 250, margin: 10}} source={{uri: props.data[1].posterURLs.original}}></Image>
                    </Pressable>

                    </View>

                    <View style={{alignItems: "center", flexDirection: "row"}}>

                    <Pressable style={{width: "50%"}} onPress={() => [props.setDialogObject(props.data[2]), props.changeVisibility()]}>
                        <Image style={{ height: 250, margin: 10}} source={{uri: props.data[2].posterURLs.original}}></Image>
                    </Pressable>

                    <Pressable style={{width: "50%"}} onPress={() => [props.setDialogObject(props.data[3]), props.changeVisibility()]}>
                        <Image style={{ height: 250, margin: 10}} source={{uri: props.data[3].posterURLs.original}}></Image>
                    </Pressable>

                    </View>
                    <View style={{alignItems: "center", flexDirection: "row"}}>

                    <Pressable style={{width: "50%"}} onPress={() => [props.setDialogObject(props.data[4]), props.changeVisibility()]}>
                        <Image style={{ height: 250, margin: 10}} source={{uri: props.data[4].posterURLs.original}}></Image>
                    </Pressable>

                    </View>

            </View>
        );

        
    } else if (props.data.length == 6) {
        return(
            <View>
                    
                    <View style={{alignItems: "center", flexDirection: "row"}}>

                    <Pressable style={{width: "50%"}} onPress={() => [props.setDialogObject(props.data[0]), props.changeVisibility()]}>
                        <Image style={{ height: 250, margin: 10}} source={{uri: props.data[0].posterURLs.original}}></Image>
                    </Pressable>

                    <Pressable style={{width: "50%"}} onPress={() => [props.setDialogObject(props.data[1]), props.changeVisibility()]}>
                        <Image style={{ height: 250, margin: 10}} source={{uri: props.data[1].posterURLs.original}}></Image>
                    </Pressable>

                    </View>

                    <View style={{alignItems: "center", flexDirection: "row"}}>

                    <Pressable style={{width: "50%"}} onPress={() => [props.setDialogObject(props.data[2]), props.changeVisibility()]}>
                        <Image style={{ height: 250, margin: 10}} source={{uri: props.data[2].posterURLs.original}}></Image>
                    </Pressable>

                    <Pressable style={{width: "50%"}} onPress={() => [props.setDialogObject(props.data[3]), props.changeVisibility()]}>
                        <Image style={{ height: 250, margin: 10}} source={{uri: props.data[3].posterURLs.original}}></Image>
                    </Pressable>

                    </View>

                    <View style={{alignItems: "center", flexDirection: "row"}}>

                    <Pressable style={{width: "50%"}} onPress={() => [props.setDialogObject(props.data[4]), props.changeVisibility()]}>
                        <Image style={{ height: 250, margin: 10}} source={{uri: props.data[4].posterURLs.original}}></Image>
                    </Pressable>

                    <Pressable style={{width: "50%"}} onPress={() => [props.setDialogObject(props.data[5]), props.changeVisibility()]}>
                        <Image style={{ height: 250, margin: 10}} source={{uri: props.data[5].posterURLs.original}}></Image>
                    </Pressable>

                    </View>

            </View>
        );
        
    } else if (props.data.length == 7) {
        return(
            <View>
                    
                    <View style={{alignItems: "center", flexDirection: "row"}}>

                    <Pressable style={{width: "50%"}} onPress={() => [props.setDialogObject(props.data[0]), props.changeVisibility()]}>
                        <Image style={{ height: 250, margin: 10}} source={{uri: props.data[0].posterURLs.original}}></Image>
                    </Pressable>

                    <Pressable style={{width: "50%"}} onPress={() => [props.setDialogObject(props.data[1]), props.changeVisibility()]}>
                        <Image style={{ height: 250, margin: 10}} source={{uri: props.data[1].posterURLs.original}}></Image>
                    </Pressable>

                    </View>

                    <View style={{alignItems: "center", flexDirection: "row"}}>

                    <Pressable style={{width: "50%"}} onPress={() => [props.setDialogObject(props.data[2]), props.changeVisibility()]}>
                        <Image style={{ height: 250, margin: 10}} source={{uri: props.data[2].posterURLs.original}}></Image>
                    </Pressable>

                    <Pressable style={{width: "50%"}} onPress={() => [props.setDialogObject(props.data[3]), props.changeVisibility()]}>
                        <Image style={{ height: 250, margin: 10}} source={{uri: props.data[3].posterURLs.original}}></Image>
                    </Pressable>

                    </View>

                    <View style={{alignItems: "center", flexDirection: "row"}}>

                    <Pressable style={{width: "50%"}} onPress={() => [props.setDialogObject(props.data[4]), props.changeVisibility()]}>
                        <Image style={{ height: 250, margin: 10}} source={{uri: props.data[4].posterURLs.original}}></Image>
                    </Pressable>

                    <Pressable style={{width: "50%"}} onPress={() => [props.setDialogObject(props.data[5]), props.changeVisibility()]}>
                        <Image style={{ height: 250, margin: 10}} source={{uri: props.data[5].posterURLs.original}}></Image>
                    </Pressable>

                    </View>

                    <View style={{alignItems: "center", flexDirection: "row"}}>

                    <Pressable style={{width: "50%"}} onPress={() => [props.setDialogObject(props.data[6]), props.changeVisibility()]}>
                        <Image style={{ height: 250, margin: 10}} source={{uri: props.data[6].posterURLs.original}}></Image>
                    </Pressable>

                    </View>

            </View>
        );
        
    } else if (props.data.length == 8) {
        return(
            <View>
                    
                <View style={{alignItems: "center", flexDirection: "row"}}>

                    <Pressable style={{width: "50%"}} onPress={() => [props.setDialogObject(props.data[0]), props.changeVisibility()]}>
                        <Image style={{ height: 250, margin: 10}} source={{uri: props.data[0].posterURLs.original}}></Image>
                    </Pressable>

                    <Pressable style={{width: "50%"}} onPress={() => [props.setDialogObject(props.data[1]), props.changeVisibility()]}>
                        <Image style={{ height: 250, margin: 10}} source={{uri: props.data[1].posterURLs.original}}></Image>
                    </Pressable>

                </View>

                <View style={{alignItems: "center", flexDirection: "row"}}>

                    <Pressable style={{width: "50%"}} onPress={() => [props.setDialogObject(props.data[2]), props.changeVisibility()]}>
                        <Image style={{ height: 250, margin: 10}} source={{uri: props.data[2].posterURLs.original}}></Image>
                    </Pressable>

                    <Pressable style={{width: "50%"}} onPress={() => [props.setDialogObject(props.data[3]), props.changeVisibility()]}>
                        <Image style={{ height: 250, margin: 10}} source={{uri: props.data[3].posterURLs.original}}></Image>
                    </Pressable>

                </View>

                <View style={{alignItems: "center", flexDirection: "row"}}>

                    <Pressable style={{width: "50%"}} onPress={() => [props.setDialogObject(props.data[4]), props.changeVisibility()]}>
                        <Image style={{ height: 250, margin: 10}} source={{uri: props.data[4].posterURLs.original}}></Image>
                    </Pressable>

                    <Pressable style={{width: "50%"}} onPress={() => [props.setDialogObject(props.data[5]), props.changeVisibility()]}>
                        <Image style={{ height: 250, margin: 10}} source={{uri: props.data[5].posterURLs.original}}></Image>
                    </Pressable>

                </View>

                <View style={{alignItems: "center", flexDirection: "row"}}>

                    <Pressable style={{width: "50%"}} onPress={() => [props.setDialogObject(props.data[6]), props.changeVisibility()]}>
                        <Image style={{ height: 250, margin: 10}} source={{uri: props.data[6].posterURLs.original}}></Image>
                    </Pressable>

                    <Pressable style={{width: "50%"}} onPress={() => [props.setDialogObject(props.data[7]), props.changeVisibility()]}>
                        <Image style={{ height: 250, margin: 10}} source={{uri: props.data[7].posterURLs.original}}></Image>
                    </Pressable>

                </View>

            </View>
        );
    }
};

export {Display};