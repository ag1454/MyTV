import { StyleSheet } from "react-native-web";

export default StyleSheet.create({
    dropdownCategory: {
        height: 50,
        borderColor: 'black',
        borderWidth: 1,
        paddingHorizontal: 8,
        backgroundColor: 'white',
        marginTop: 20,
        margin: 5,
        borderRadius: 6
    },

    dropdownMedia: {
        height: 50,
        borderColor: 'black',
        borderWidth: 1,
        paddingHorizontal: 8,
        backgroundColor: 'white',
        marginTop: 20,
        margin: 5,
        borderRadius: 6
    },

    descText: {
        fontSize: 18,
        marginTop: 5,
    },

    button: {
        padding: 5,
        marginTop: 20,
        marginLeft: 5,
        width: '115%',
    },

    elementText: {
        fontSize: "18"
    }
});