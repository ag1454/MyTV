import { StyleSheet } from "react-native-web";

export default StyleSheet.create({
    row: {
        flexDirection: "row",
        flexWrap: "wrap",
    },

    container: {
        backgroundColor: '#f2f2f2',
        padding: 10,
    },

    cardContainer: {
        backgroundColor: '#a3cddb',
        borderRadius: 30,
        marginBottom: 20,
    },

    scrollContainer: {
        padding: 10,
        marginBottom: 5,
        height: "80%"
    },

    dropdown: {
        height: 50,
        width: 115,
        borderColor: 'gray',
        borderWidth: 0.5,
        borderRadius: 8,
        paddingHorizontal: 8,
    },

    dropdownGenre: {
      height: 50,
      width: 160,
      borderColor: 'gray',
      borderWidth: 0.5,
      borderRadius: 8,
      paddingHorizontal: 8,
    },

    icon: {
        marginRight: 5,
    },

    label: {
        position: 'absolute',
        backgroundColor: '#f2f2f2',
        left: 22,
        top: 8,
        zIndex: 999,
        paddingHorizontal: 8,
        fontSize: 14,
    },

    placeholderStyle: {
        fontSize: 16,
    },

    selectedTextStyle: {
        fontSize: 16,
    },

    iconStyle: {
        width: 20,
        height: 20,
    },

    inputSearchStyle: {
        height: 40,
        fontSize: 16,
    },
});