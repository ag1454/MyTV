import { StyleSheet } from "react-native-web";

export default StyleSheet.create({
    top: {
        flex: 1,
        alignItems: 'center',
        marginTop: 25,
      },
  
      middle: {
        marginTop: 30,
        backgroundColor: "white",
        justifyContent: "center",
        marginRight: 5,
        marginLeft: 5,
        borderRadius: 6,
        shadowColor: "#222222",
        shadowOpacity: 0.8,
        shadowRadius: 2,
        shadowOffset: {
          height: 1,
          width: 1
        }
      },

      bottom: {
        marginTop: 20,
        backgroundColor: "white",
        justifyContent: "center",
        marginRight: 5,
        marginLeft: 5,
        borderRadius: 6,
        shadowColor: "#222222",
        shadowOpacity: 0.8,
        shadowRadius: 2,
        shadowOffset: {
          height: 1,
          width: 1
        }
      },
  
      button: {
        alignItems: 'center',
        justifyContent: 'center',
        textColor: "black",
        marginTop: 20,
        borderRadius: 4,
        elevation: 3,
        backgroundColor: "#D5DCDC",
        borderRadius: 41,
        height: 50,
        width: 350,
      },

      button2: {
        alignItems: 'center',
        justifyContent: 'center',
        textColor: "black",
        marginTop: 10,
        borderRadius: 4,
        elevation: 3,
        backgroundColor: "#D5DCDC",
        borderRadius: 41,
        height: 50,
        width: 300,
      },
  
      listBox: {
        backgroundColor: "#F2F2F2",
        indicatorStyle: "black",
      },
  
      text1: {
        fontSize: 16,
        lineHeight: 21,
        letterSpacing: 0.25,
        color: 'black',
      },
  
      text2: {
        fontSize: 20,
        lineHeight: 21,
        letterSpacing: 0.25,
        color: 'black',
        textAlign: "center",
        paddingTop: 14
      },
  
      text3: {
        fontSize: 20,
        lineHeight: 21,
        letterSpacing: 0.25,
        marginTop: 14,
        paddingBottom: 5,
        color: 'black',
        alignSelf: "center"
      },
  
      listText: {
        fontSize: 20,
        padding: 15,
      },
    
      alphaHeader: {
        fontSize: 18,
        padding: 10,
        fontWeight: "bold",
      },

      changeBanner: {
        left: 0,
        right: 0,
        bottom: 0,
        height: 90,
        justifyContent: 'center',
        alignItems: 'center',

      },

      suspendButton: {  
        paddingTop: 10,
        alignItems: 'center',
        paddingBottom: 70
    },

      poster: {
        height: 250,
        width: '45%',
        margin: 10,
        borderRadius: 6,
      },

      followContainer: {
        flexDirection: 'row',
        shadowColor: "#222222",
        shadowOpacity: 0.8,
        shadowRadius: 2,
        shadowOffset: {
          height: 1,
          width: 1
        }
      },

      followInfo: {
        padding: 10,
        flex: 1,
        backgroundColor: 'white',
        borderRadius: 6,
        height: 250,
        width: '50%',
        margin: 10,
      },
});