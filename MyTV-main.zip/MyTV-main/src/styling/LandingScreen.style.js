import { StyleSheet } from "react-native-web";

export default StyleSheet.create({
    top: {
        flex: 0.5,
        alignItems: "center"
      },
    
      middle: {
        flex: 0.5,
        alignItems: "center"
      },
    
      myTV: { 
        marginTop: 200,
        fontWeight: "bold",
        textAlign: "center",
        textAlignVertical: "center",
        fontSize: 90,
        color: "black",
        
      },
    
      container: {
        flex: 1,
        backgroundColor: '#55b0ca',
        alignItems: 'center',
        justifyContent: 'center',
      },
      
      text: {
        fontSize: 16,
        lineHeight: 21,
        fontWeight: 'bold',
        letterSpacing: 0.25,
        color: 'white',
      },
});