import { StyleSheet } from "react-native-web";

export default StyleSheet.create({
    top: {
        alignItems: "center",
      },
    
      middle: {
        alignItems: "center",
      },
    
      container: {
        flex: 1,
        backgroundColor: '#55b0ca',
        alignItems: 'center',
        justifyContent: 'center',
      },
    
      textInputs: {
        width: 300,
        marginTop: 20,
        borderTopLeftRadius: 4,
        borderTopRightRadius: 4,      
      },
   
      text1: {
        fontSize: 16,
        lineHeight: 21,
        fontWeight: 'bold',
        letterSpacing: 0.25,
        color: 'white',
      },
  
      myTV: { 
          fontWeight: "bold",
          textAlign: "center",
          textAlignVertical: "center",
          fontSize: 90,
          color: "black",
      }
});