import { StyleSheet } from "react-native-web";

export default StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "white",
        // backgroundColor: "#f0f0f0"
    },  

    initialView: {
        paddingTop: 200,
        justifyContent: 'center', 
        alignItems: 'center',
    },

    netflixImage: {
        width: 80,
        height: 80,
        marginLeft: 122,
    },

    hboImage: {
        width: 160,
        height: 80,
        marginLeft: 90,
    },

    huluImage: {
        width: 160,
        height: 80,
        marginLeft: 90,
    },

    disneyImage: {
        width: 160,
        height: 80,
        marginLeft: 90,
    },

    'Disney+': {
        backgroundColor: "#0E47A1"
    },
    HBO: {
        backgroundColor: "#000021"
    }, 
    Hulu: {
        backgroundColor: "black"
    },
    Netflix: {
        backgroundColor: "black"

    },

    cardView: {
        paddingTop: 5, 
    },

    contentContainer: {
        alignItems: "center",
    },

    changeBanner: {
        position: 'absolute',
        left: 0,
        right: 0,
        bottom: 0,
        height: 90,
        backgroundColor: '#99cfdf',
        justifyContent: 'center',
        alignItems: 'center'
    }
});