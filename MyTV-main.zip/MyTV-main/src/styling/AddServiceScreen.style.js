import { StyleSheet } from "react-native-web";

export default StyleSheet.create({
    
    top: {
        alignItems: "center"
    },
  
    middle: {
        marginTop: 35,
        flexDirection: 'row'
    },

    middle2: {
        marginTop: 35,
        flexDirection: 'row',
        paddingLeft: '12%'
    },

    date: {
        flexDirection: "row",
        marginTop: 35,
        width: 300,
    },
    
    text: { 
        fontWeight: "bold",
        textAlign: "center",
        textAlignVertical: "center",
        fontSize: 30,
        color: "black",
        marginTop: 50,
    },
  
    text2: {
        color: "black",
        marginRight: 10,
        fontSize: 20,
    },
    
    container1: {
        flex: 1,
        backgroundColor: 'white',
        alignItems: 'center',
        justifyContent: 'center',
    },
  
    container: {
        backgroundColor: 'white',
        padding: 16,
        width: 300,
        marginTop: 30,
    },
  
    dropdown: {
        height: 50,
        borderColor: 'black',
        borderWidth: 0.5,
        borderRadius: 8,
        paddingHorizontal: 8,
    },
  
    label: {
        position: 'absolute',
        backgroundColor: 'white',
        left: 22,
        top: 8,
        zIndex: 999,
        paddingHorizontal: 8,
        fontSize: 14,
    },
  
    placeholderStyle: {
        fontSize: 16,
    },
  
    selectedTextStyle: {
        fontSize: 16,
    },
      
    iconStyle: {
        width: 20,
        height: 20,
    },
      
    inputSearchStyle: {
        height: 40,
        fontSize: 16,
    },
});