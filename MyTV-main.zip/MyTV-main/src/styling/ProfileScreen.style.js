import { StyleSheet } from "react-native-web";

export default StyleSheet.create({
    container: {
        backgroundColor: 'white',
        flex: 1
      },
  
      myTV: { 
        fontWeight: "bold",
        textAlign: "center",
        textAlignVertical: "center",
        fontSize: 30,
        color: "black",
      },
  
      avatar: {
        position: "absolute",
        alignSelf: "center",
        paddingTop: 60,
      },
});