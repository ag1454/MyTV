import { StyleSheet } from "react-native-web";

export default StyleSheet.create({
    dropdownGenre: {
        height: 50,
        borderColor: 'gray',
        borderWidth: 1,
        paddingHorizontal: 8,
    },

    iconStyle: {
        width: 20,
        height: 20,
    },
});