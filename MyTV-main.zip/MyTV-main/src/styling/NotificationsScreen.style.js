import { StyleSheet } from "react-native-web";

export default StyleSheet.create({

    NotifText: {
        marginBottom: 10,
        textAlign: "center",
        fontSize: 16,
    },

    NotifView: {
        marginTop: 10,
    },

    NotifBorder: {
        width: '100%',
        borderBottomWidth: 1,
        borderBottomColor: "#e3e3e3",
    }
});