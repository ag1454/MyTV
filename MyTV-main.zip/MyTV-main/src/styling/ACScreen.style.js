import { StyleSheet } from "react-native-web";

export default StyleSheet.create({
    top: {
      alignItems: "center",
      paddingTop: 30
    },
  
    text: { 
      fontWeight: "bold",
      textAlign: "center",
      textAlignVertical: "center",
      fontSize: 30,
      color: "white",
    },
  
    container: {
      flex: 1,
      backgroundColor: '#55b0ca',
      alignItems: 'center',
    },
  
    textInputs: {
      width: 300,
      marginTop: 10,
      borderTopLeftRadius: 4,
      borderTopRightRadius: 4,
    },
  
    text1: {
      fontSize: 16,
      lineHeight: 21,
      fontWeight: 'bold',
      letterSpacing: 0.25,
      color: 'white',
    },

    texterror: {
        backgroundColor: "red",
        fontSize: 14,
        color: 'white',
        fontWeight: 'bold',
        textAlign: 'center',
        marginTop: '.5%',
    },

    inputContainer: {
      flexDirection: 'row',
      alignItems: 'center',
    },
});