import { getAuth } from "firebase/auth";
import { getDatabase, ref, update, push, child, get, onValue, set } from "firebase/database";
import { firebase, db } from "../../firebase-config.js";

//
// Function to get the movies that are leaving from the API for each service and save it to the database
//
function moviesLeaving() {
    
    // Config
    var services = ['Netflix', 'Hulu', 'HBO', 'Disney']
    const auth = getAuth();
    const dbRef = ref(getDatabase());

    leaving('netflix', 'Netflix')
    leaving('hulu', 'Hulu')
    leaving('hbo', 'HBO')
    leaving('disney', 'Disney')

    //
    // API call
    //
    function leaving(service, dbService) {
        // movie or series

        const fetch = require('node-fetch');

        const url = 'https://streaming-availability.p.rapidapi.com/changes?' +
                    'service=' + service + '&' +
                    'country=us&' +
                    'change_type=removed&' +
                    'type=movie&' +
                    'output_language=en';

        const options = {
        method: 'GET',
        headers: {
            'X-RapidAPI-Key': '1b11125fe6msh8a001dd71a23db7p15705cjsn96bb6fc93404',
            'X-RapidAPI-Host': 'streaming-availability.p.rapidapi.com'
        }
        };

        fetch(url, options)
            .then(res => res.json())
            .then(json => {
                // console.log("Titles being removed: " + json.results.length)
                // console.log(json.results[82].title)
        
                for(var i = 0; i < json.results.length; i++) {
                    set(child(dbRef, `MoviesLeaving/${dbService}/${json.results[i].imdbID}`), {
                        "title": json.results[i].title,
                    })    
                }

            })
            .catch(err => console.error('error:' + err));
    }  
}

export {moviesLeaving}