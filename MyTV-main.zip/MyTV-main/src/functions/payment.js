import { getAuth } from "firebase/auth";
import { getDatabase, ref, update, push, child, get, onValue, set } from "firebase/database";
import { firebase, db } from "../../firebase-config.js";

//
// Function to "make" a payment, save a payment, and set a new renewalDate
//
function payment(service, subscriptionInfo) {

    let currentDate = new Date();

    let renewalDate = new Date(subscriptionInfo.renewalDate);

    const diffTime = (renewalDate - currentDate);

    // Difference between renewal date and the current date
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); 

    if (diffDays < 0) {
        //Add new payment        
        const auth = getAuth();
        let uid = auth.currentUser.uid;
        const db = getDatabase();

        get(ref(db, `users/${uid}/services/${service}/subscription/payments`)).then((snapshot) => {
            
            let key = snapshot.size;

            set(ref(db, `users/${uid}/services/${service}/subscription/payments/${key}`), {
                "date": subscriptionInfo.renewalDate,
                "price": subscriptionInfo.price
            });      
        })  

        //Change renewal date  
        let newRenewalDate = new Date(renewalDate.setMonth(renewalDate.getMonth()+1));

        let dd = String(newRenewalDate.getDate()).padStart(2, '0');
        let mm = String(newRenewalDate.getMonth() + 1).padStart(2, '0');
        let yyyy = newRenewalDate.getFullYear();

        newRenewalDate = mm + '/' + dd + '/' + yyyy;

        update(ref(db, `users/${uid}/services/${service}/subscription/`), {
            "renewalDate": newRenewalDate
        });    
    }
    
    return subscriptionInfo;

}

export {payment}