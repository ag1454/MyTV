import { browserLocalPersistence, checkActionCode, getAuth } from "firebase/auth";
import { getDatabase, ref, update, push, child, get, onValue, set } from "firebase/database";
import { firebase, db } from "../../firebase-config.js";

var disneyMovieData = []
var netflixMovieData = []
var hboMovieData = []
var huluMovieData = []
var disneySeriesData = []
var netflixSeriesData = []
var hboSeriesData = []
var huluSeriesData = []

var disneyFollowingData = []
var netflixFollowingData = []
var huluFollowingData = []
var hboFollowingData = []

var disneyNotificationData = []
var netflixNotificationData = []
var huluNotificationData = []
var hboNotificationData = []

//
// Function to get the movies that are leaving from the API for each service and save it to the database
//
function generate() {

    // Config
    const auth = getAuth();
    let uid = auth.currentUser.uid;
    const dbRef = ref(getDatabase());

    //
    // Getting movies that are leaving
    //
    get(child(dbRef, `MoviesLeaving`)).then((snapshot) => {
        if (snapshot.exists()) {
            let data = snapshot.val();
            disneyMovieData = Object.values(data.Disney);
            netflixMovieData= Object.values(data.Netflix);
            hboMovieData = Object.values(data.HBO);
            huluMovieData = Object.values(data.Hulu);  
        } else {
            console.log("No data available");
        }
        }).catch((error) => {
          console.error(error);
    });

    //
    // Getting series that are leaving
    //
    get(child(dbRef, `SeriesLeaving`)).then((snapshot) => {
        if (snapshot.exists()) {
            let data = snapshot.val();
            disneySeriesData = Object.values(data.Disney);
            netflixSeriesData= Object.values(data.Netflix);
            hboSeriesData = Object.values(data.HBO);
            huluSeriesData = Object.values(data.Hulu);
        } else {
            console.log("No data available");
        }
        }).catch((error) => {
          console.error(error);
    });

    //
    // Getting following data
    //
    get(child(dbRef, `users/${uid}/services`)).then((snapshot) => {
        if (snapshot.exists()) {
            let data = snapshot.val();
            var services = Object.keys(data)

            if(services.includes("Disney")) {
                if(data.Disney.notifications) {
                    disneyNotificationData = Object.values(data.Disney.notifications)
                }
                if(data.Disney.following){
                    disneyFollowingData = (Object.keys(data.Disney.following))
                    compare("Disney", disneyFollowingData, disneyMovieData, disneySeriesData, disneyNotificationData)
                }
            }


            if(services.includes("Netflix")) {
                if(data.Netflix.notifications) {
                    netflixNotificationData = Object.values(data.Netflix.notifications)
                }
                if(data.Netflix.following){
                    netflixFollowingData = (Object.keys(data.Netflix.following))
                    compare("Netflix", netflixFollowingData, netflixMovieData, netflixSeriesData, netflixNotificationData)

                }
            }


            if(services.includes("HBO")) {
                if(data.HBO.notifications) {
                    hboNotificationData = Object.values(data.HBO.notifications)
                }
                if(data.HBO.following){
                    hboFollowingData = (Object.keys(data.HBO.following))
                    compare("HBO", hboFollowingData, hboMovieData, hboSeriesData, hboNotificationData)
                }
            }


            if(services.includes("Hulu")) {
                if(data.Hulu.notifications) {
                    huluNotificationData = Object.values(data.Hulu.notifications)
                }
                if(data.Hulu.following){
                    huluFollowingData = (Object.keys(data.Hulu.following))
                    compare("Hulu", huluFollowingData, huluMovieData, huluSeriesData, huluNotificationData)
                }
            }

        } else {
            console.log("No data available");
        }
        }).catch((error) => {
          console.error(error);
    });


    //
    // Function to compare following data to API data
    //
    function compare(service, followingData, movieData, seriesData, notificationData) {

        var data = []


        // Loop through followingData
        for(var i = 0; i < followingData.length; i++) {

            // Loop through seriesData
            for(var j = 0; j < seriesData.length; j++) {
                if(followingData[i] == seriesData[j].title) {
                    // console.log(followingData[i])
                    let status = check(followingData[i], notificationData)
                    if(status == false) {
                        data.push(followingData[i])
                    } 
                } 
            }

            // Loop through movieData
            for(var l = 0; l < movieData.length; l++) {
                if(followingData[i] == movieData[l].title) {
                    // console.log(followingData[i])
                    let status = check(followingData[i], notificationData)
                    if(status == false) {
                        data.push(followingData[i])
                    } 
                }
            }
        }
        save(service, data)
    }
    
    //
    // function to check if notification has already been made
    //
    function check(title, notificationData) {
        for(var i = 0; i < notificationData.length; i++) {
            if(title == notificationData[i].title) {
                console.log(title + " notification already generated!")
                return true;
            }
        }
        return false;
    }

    //
    // Save the notification to the database
    //
    function save(service, data) {

        for(var i = 0; i < data.length; i++) {
            push(child(dbRef, `users/${uid}/services/${service}/notifications`), {
                "title": data[i]
            })    
        }
    }

}

export {generate}