// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import { getDatabase } from 'firebase/database';
import * as firebase from 'firebase/app';
import AsyncStorage from "@react-native-async-storage/async-storage";
import {getReactNativePersistence, initializeAuth} from 'firebase/auth/react-native';

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyAFB7ZuC71XGzG79BZ_zdzGQIOaupaBlj0",
  authDomain: "mytv-subscription-manager.firebaseapp.com",
  databaseURL: "https://mytv-subscription-manager-default-rtdb.firebaseio.com",
  projectId: "mytv-subscription-manager",
  storageBucket: "mytv-subscription-manager.appspot.com",
  messagingSenderId: "140397007958",
  appId: "1:140397007958:web:b5be60e387a7f85a0857f7",
  measurementId: "G-M887ZM14Q3"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

const app = initializeApp(firebaseConfig);
const db = getDatabase(app);

initializeAuth(app, {
  persistence: getReactNativePersistence(AsyncStorage)
});

export { db, firebase };