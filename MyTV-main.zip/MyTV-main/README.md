# MyTV

Software project for CIS 471 & 472.

**<h3>Links:</h3>**

- [Jira](https://unitivity.atlassian.net/jira/software/projects/YS/boards/2/backlog?selectedIssue=YS-17)
- [Firebase](https://console.firebase.google.com/u/1/project/mytv-subscription-manager/overview)
- [Slack](https://app.slack.com/client/T2ST3UA68/C036TCUA2G7)
- [CircleCI](https://app.circleci.com/pipelines)
- [Figma](https://www.figma.com/file/AUp42ApThvUATJDhXS4rgQ/MyTV?node-id=0%3A1)
- [Standup Doc](https://docs.google.com/document/d/1b1W5xdrDwJPXCwhkmpYs93Vf40x_cn9hw-NrZCW5SY0/edit)

**<h3>Color Theme:</h3>**

- Primary: #55b0ca
- Primary Light: #99cfdf
- Primary Dark: #448ca1
- Secondary: #ca6f55
- Secondary Light: #dfa899
- Secondary Dark: #a15844
- Grey: #afaeae
- Black: black
- white: white

**<h3>How to Contribute:</h3>**

- Main branch is the production branch that will not be touched until the end of sprints by Lead Developer, Garrett Nissley. The Development branch is the staging branch where we will test our changes though our CI/CD pipeline before commiting our changes into production

- Each developer has their dev-'initials' branch, where they will tast their code and commit any changes for testing. Any pull requests must be verified with the lead developer.

**<h3>Sprint Point Scale:</h3>**

_I decided to have only stories worth up to 3 points. If we come across a story that we believe is worth more than 3 points that is our sign to break it up into pieces._

- 1 Point Stories: ~1 hour of work
- 2 Point Stories: ~3 hours of work
- 3 Point Stories: ~9 hours of work

_Keep in mind these are a work in progress and will most likely change multiple times_

**<h3>Team Contact Info</h3>**

- Garrett
  - Email: gn1166@messiah.edu
  - Phone #: 717-333-6226
- Nate
  - Email: nb1298@messiah.edu
  - Phone #: 717-659-4555
- Tyler
  - Email: regitz66@gmail.com
  - Phone #: 717-449-0058
- Abigail
  - Email: ag1454@messiah.edu
  - Phone #: 717-961-6135
- Christian
  - Email: cr1368@messiah.edu
  - Phone #: 540-522-8580
